/*
 * SPDX-License-Identifier: AGPL-3.0-or-later
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

package app.gyrolet.mpvrx.repository.ai

import app.gyrolet.mpvrx.network.awaitResponse
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody

@Serializable
private data class OrModelPricing(
  val prompt: String = "0",
  val completion: String = "0",
  val image: String = "0",
  val request: String = "0",
)

@Serializable
private data class OrModel(
  val id: String,
  val name: String? = null,
  val pricing: OrModelPricing? = null,
)

@Serializable
private data class OrModelListResponse(
  val data: List<OrModel> = emptyList(),
)

@Serializable
private data class OrMessage(
  val role: String,
  val content: String,
)

@Serializable
private data class OrErrorBody(
  val error: OrErrorDetail? = null,
)

@Serializable
private data class OrErrorDetail(
  val message: String? = null,
)

@Serializable
private data class OrChatRequest(
  val model: String,
  val messages: List<OrMessage>,
  val temperature: Double = 0.3,
  @SerialName("max_tokens") val maxTokens: Int = 200,
)

class OpenRouterClient(
  private val client: OkHttpClient,
  private val json: Json,
) : AiClient {
  companion object {
    private const val BASE_URL = "https://openrouter.ai/api/v1"
    private val JSON_MEDIA_TYPE = "application/json".toMediaType()
  }

  private val apiClient: OkHttpClient =
    client.withAiChatTimeouts()

  override suspend fun fetchModels(apiKey: String): Result<List<AiModelInfo>> =
    withContext(Dispatchers.IO) {
      runCatchingCancellable {
        val request =
          bearerGetRequest("$BASE_URL/models", apiKey)

        apiClient.newCall(request).awaitResponse().use { response ->
          val body = response.body.string()
          if (!response.isSuccessful) throw Exception("OpenRouter API error ${response.code}: ${parseError(body)}")

          val parsed = json.decodeFromString<OrModelListResponse>(body)
          parsed.data.map { model ->
            val isFree =
              model.pricing?.let { p ->
                p.prompt.toDoubleOrNull() == 0.0 &&
                  p.completion.toDoubleOrNull() == 0.0 &&
                  p.image.toDoubleOrNull() == 0.0 &&
                  p.request.toDoubleOrNull() == 0.0
              } ?: false
            AiModelInfo(
              id = model.id,
              displayName = model.name ?: model.id,
              isFree = isFree,
            )
          }
        }
      }
    }

  override suspend fun verifyKey(apiKey: String): Result<String> =
    withContext(Dispatchers.IO) {
      runCatchingCancellable {
        val request =
          bearerGetRequest("$BASE_URL/auth/key", apiKey)

        apiClient.newCall(request).awaitResponse().use { response ->
          if (!response.isSuccessful) throw Exception("Invalid API key: ${response.code}")
          "API key verified successfully"
        }
      }
    }

  override suspend fun generateContent(
    apiKey: String,
    model: String,
    instruction: String,
    userInput: String,
    options: AiGenerationOptions,
  ): Result<AiGeneratedContent> =
    withContext(Dispatchers.IO) {
      runCatchingCancellable {
        val requestBody =
          json.encodeToString(
            OrChatRequest.serializer(),
            OrChatRequest(
              model = model,
              messages =
                listOf(
                  OrMessage(role = "system", content = instruction),
                  OrMessage(role = "user", content = userInput),
                ),
              temperature = options.temperature,
              maxTokens = options.maxTokens,
            ),
          )

        val request =
          Request
            .Builder()
            .url("$BASE_URL/chat/completions")
            .header("Authorization", "Bearer $apiKey")
            .header("HTTP-Referer", "https://mpvrx.app")
            .header("X-OpenRouter-Title", "mpvRx")
            .post(requestBody.toRequestBody(JSON_MEDIA_TYPE))
            .build()

        apiClient.newCall(request).awaitResponse().use { response ->
          val body = response.body.string()
          if (!response.isSuccessful) throw Exception("OpenRouter generate error ${response.code}: ${parseError(body)}")
          AiResponseParser.openAiCompatible(json, body, "OpenRouter")
        }
      }
    }

  private fun parseError(body: String): String =
    try {
      val error = json.decodeFromString<OrErrorBody>(body)
      error.error?.message ?: body
    } catch (_: Exception) {
      body.take(200)
    }
}
