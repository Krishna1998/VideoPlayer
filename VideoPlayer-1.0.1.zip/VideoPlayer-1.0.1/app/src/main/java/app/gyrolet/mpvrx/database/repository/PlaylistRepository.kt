/*
 * SPDX-License-Identifier: AGPL-3.0-or-later
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

package app.gyrolet.mpvrx.database.repository

import android.content.Context
import android.net.Uri
import app.gyrolet.mpvrx.data.network.XtreamClient
import app.gyrolet.mpvrx.data.network.credentials.NetworkCredentialCipher
import app.gyrolet.mpvrx.data.network.credentials.NetworkCredentialStorageException
import app.gyrolet.mpvrx.database.dao.PlaylistDao
import app.gyrolet.mpvrx.database.entities.PlaylistEntity
import app.gyrolet.mpvrx.database.entities.PlaylistItemEntity
import app.gyrolet.mpvrx.domain.archive.ZipArchiveMedia
import app.gyrolet.mpvrx.domain.network.XtreamPlaybackUri
import app.gyrolet.mpvrx.preferences.YtdlPreferences
import app.gyrolet.mpvrx.ui.player.ytdlp.YtdlpManager
import app.gyrolet.mpvrx.ui.player.ytdlp.YtdlpPlaylistMetadata
import app.gyrolet.mpvrx.utils.media.HttpUtils
import app.gyrolet.mpvrx.utils.media.M3UParseResult
import app.gyrolet.mpvrx.utils.media.M3UParser
import app.gyrolet.mpvrx.utils.media.M3UPlaylistItem
import app.gyrolet.mpvrx.utils.storage.LocalPlaylistScanner
import app.gyrolet.mpvrx.utils.sort.SortUtils
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import java.net.URLDecoder
import java.nio.charset.StandardCharsets
import java.util.UUID

/**
 * One entry to append to a playlist.
 *
 * [fileSize] only applies to network entries — local entries resolve their size from the file, and
 * leaving it null keeps them doing exactly that.
 */
data class PlaylistItemInput(
  val filePath: String,
  val fileName: String,
  val fileSize: Long? = null,
)


class PlaylistRepository(
  private val playlistDao: PlaylistDao,
  private val httpClient: OkHttpClient,
  private val applicationContext: Context,
  private val ytdlPreferences: YtdlPreferences,
  private val credentialCipher: NetworkCredentialCipher,
  private val xtreamClient: XtreamClient,
) {
  companion object {
    const val FAVORITES_PLAYLIST_NAME = "Favorites"
  }

  private val playlistWriteMutex = Mutex()
  private val zipPlaylistMutex = Mutex()
  private val remotePlaylistWriteMutex = Mutex()
  private val localPlaylistScanMutex = Mutex()
  private val localPlaylistRevisions = mutableMapOf<String, Triple<String, Long, Long>>()
  private val localPlaylistPreferences = applicationContext.getSharedPreferences("local_playlist_discovery", Context.MODE_PRIVATE)

  // Playlist operations
  suspend fun createPlaylist(
    name: String,
    isAudio: Boolean = false,
  ): Long {
    val now = System.currentTimeMillis()
    return playlistDao.insertPlaylist(
      PlaylistEntity(
        name = name,
        createdAt = now,
        updatedAt = now,
        isAudio = isAudio,
      ),
    )
  }

  suspend fun getOrCreateFavoritesPlaylist(isAudio: Boolean = true): PlaylistEntity =
    playlistWriteMutex.withLock { getOrCreateFavoritesPlaylistLocked(isAudio) }

  suspend fun createZipPlaylist(uri: Uri): Result<Long> = zipPlaylistMutex.withLock { createZipPlaylistLocked(uri) }

  private suspend fun createZipPlaylistLocked(uri: Uri): Result<Long> = withContext(Dispatchers.IO) {
    val resolver = applicationContext.contentResolver
    val hadPermission = resolver.persistedUriPermissions.any { it.uri == uri && it.isReadPermission }
    var saved = false
    try {
      if (uri.scheme == "content" && !hadPermission) {
        resolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
      }
      val archive = ZipArchiveMedia.playlistContent(applicationContext, uri)
      val sourceKey = ZipArchiveMedia.browserPath(archive.source)
      val videos = archive.videos.sortedWith(compareBy(SortUtils.NaturalOrderComparator.DEFAULT) { it.path })
      currentCoroutineContext().ensureActive()
      val playlistId = playlistWriteMutex.withLock {
        val previous = playlistDao.getAllPlaylists().firstOrNull { it.isZipPlaylist && it.m3uSourceUrl == sourceKey }
        val previousItems = previous?.let { playlistDao.getPlaylistItems(it.id) }.orEmpty().associateBy { it.filePath }
        val now = System.currentTimeMillis()
        val playlist = previous?.copy(updatedAt = now) ?: PlaylistEntity(
          name = archive.name,
          createdAt = now,
          updatedAt = now,
          m3uSourceUrl = sourceKey,
        )
        val items = videos.mapIndexed { index, video ->
          val entryName = ZipArchiveMedia.entryPathOf(video.path) ?: video.displayName
          previousItems[video.path]?.copy(position = index, fileName = entryName, fileSize = video.size)
            ?: PlaylistItemEntity(
              playlistId = playlist.id,
              filePath = video.path,
              fileName = entryName,
              position = index,
              addedAt = now,
              fileSize = video.size,
            )
        }
        if (previous == null) {
          playlistDao.insertPlaylistWithItems(playlist, items)
        } else {
          playlistDao.replacePlaylistItems(playlist, items)
          playlist.id.toLong()
        }.also { saved = true }
      }
      Result.success(playlistId)
    } catch (cancelled: CancellationException) {
      throw cancelled
    } catch (error: Exception) {
      Result.failure(error)
    } finally {
      if (!saved && !hadPermission && uri.scheme == "content") {
        runCatching { resolver.releasePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
      }
    }
  }

  private suspend fun getOrCreateFavoritesPlaylistLocked(isAudio: Boolean): PlaylistEntity {
    val existing = playlistDao.getAllPlaylists().find {
      it.name.equals(FAVORITES_PLAYLIST_NAME, ignoreCase = true) && it.isAudio == isAudio
    }
    if (existing != null) return existing

    val id = createPlaylist(name = FAVORITES_PLAYLIST_NAME, isAudio = isAudio)
    return getPlaylistById(id.toInt()) ?: PlaylistEntity(
      id = id.toInt(),
      name = FAVORITES_PLAYLIST_NAME,
      createdAt = System.currentTimeMillis(),
      updatedAt = System.currentTimeMillis(),
      isAudio = isAudio,
    )
  }

  fun isProtectedPlaylist(playlist: PlaylistEntity): Boolean {
    return playlist.name.equals(FAVORITES_PLAYLIST_NAME, ignoreCase = true)
  }

  fun observeIsFavorite(filePath: String, isAudio: Boolean = true): Flow<Boolean> =
    playlistDao.observeAllPlaylists().map { playlists ->
      if (filePath.isBlank()) return@map false
      val favPlaylist = playlists.find { it.name.equals(FAVORITES_PLAYLIST_NAME, ignoreCase = true) && it.isAudio == isAudio }
        ?: return@map false
      val items = playlistDao.getPlaylistItems(favPlaylist.id)
      items.any { isPathMatching(it.filePath, filePath) }
    }

  suspend fun isFavorite(filePath: String, isAudio: Boolean = true): Boolean {
    if (filePath.isBlank()) return false
    val favPlaylist = playlistDao.getAllPlaylists().find {
      it.name.equals(FAVORITES_PLAYLIST_NAME, ignoreCase = true) && it.isAudio == isAudio
    } ?: return false
    val items = playlistDao.getPlaylistItems(favPlaylist.id)
    return items.any { isPathMatching(it.filePath, filePath) }
  }

  suspend fun toggleFavorite(filePath: String, fileName: String, isAudio: Boolean = true): Boolean {
    if (filePath.isBlank()) return false
    val cleanPath = normalizePlaylistPath(filePath)
    return playlistWriteMutex.withLock {
      val favPlaylist = getOrCreateFavoritesPlaylistLocked(isAudio)
      val items = playlistDao.getPlaylistItems(favPlaylist.id)
      val existing = items.filter { isPathMatching(it.filePath, cleanPath) }
      if (existing.isNotEmpty()) {
        playlistDao.deletePlaylistItems(existing)
        updatePlaylist(favPlaylist)
        false
      } else {
        addItemToPlaylistLocked(favPlaylist.id, cleanPath, fileName)
      }
    }
  }

  private fun normalizePlaylistPath(filePath: String): String =
    if (filePath.startsWith("file://", ignoreCase = true)) Uri.parse(filePath).path ?: filePath else filePath

  private fun playlistPathKey(filePath: String): String {
    val cleanPath = normalizePlaylistPath(filePath)
    val uri = runCatching { Uri.parse(cleanPath) }.getOrNull() ?: return cleanPath
    return if (uri.scheme.isNullOrBlank()) cleanPath else uri.normalizeScheme().toString()
  }

  private fun isPathMatching(pathA: String, pathB: String): Boolean =
    pathA.isNotBlank() && pathB.isNotBlank() && playlistPathKey(pathA) == playlistPathKey(pathB)

  suspend fun updatePlaylist(playlist: PlaylistEntity) {
    playlistDao.updatePlaylist(playlist.copy(updatedAt = System.currentTimeMillis()))
  }

  suspend fun deletePlaylist(playlist: PlaylistEntity) {
    if (isProtectedPlaylist(playlist)) return
    withContext(Dispatchers.IO) {
      remotePlaylistWriteMutex.withLock {
        playlistDao.deletePlaylist(playlist)
        localPlaylistSourceKey(playlist.m3uSourceUrl)?.let { key ->
          localPlaylistPreferences.edit().putStringSet("ignored_sources", ignoredLocalPlaylistSources() + key).apply()
        }
      }
    }
  }

  fun prioritizeFavorites(playlists: List<PlaylistEntity>): List<PlaylistEntity> {
    return playlists.sortedWith(
      compareByDescending<PlaylistEntity> { isProtectedPlaylist(it) }
        .thenBy { it.name.lowercase() }
    )
  }

  fun observeAllPlaylists(isAudio: Boolean? = null): Flow<List<PlaylistEntity>> =
    playlistDao.observeAllPlaylists().map { playlists ->
      val filtered = if (isAudio == null) {
        playlists
      } else {
        classifyAndFilterPlaylists(playlists, isAudio)
      }
      prioritizeFavorites(filtered)
    }

  suspend fun getAllPlaylists(isAudio: Boolean? = null): List<PlaylistEntity> {
    val playlists = playlistDao.getAllPlaylists()
    val filtered = if (isAudio == null) {
      playlists
    } else {
      classifyAndFilterPlaylists(playlists, isAudio)
    }
    return prioritizeFavorites(filtered)
  }

  private suspend fun classifyAndFilterPlaylists(
    playlists: List<PlaylistEntity>,
    targetIsAudio: Boolean,
  ): List<PlaylistEntity> {
    val result = mutableListOf<PlaylistEntity>()
    for (playlist in playlists) {
      // M3U/IPTV lists can mix radio and video entries. Keep them in the playlist section
      // where they were imported instead of moving the whole list after spotting one audio URL.
      if (playlist.isM3uPlaylist || playlist.isZipPlaylist) {
        if (!targetIsAudio) result.add(playlist)
        continue
      }
      var effectiveIsAudio = playlist.isAudio
      // Favorites lists are per media type; reclassifying one would leave its type without one.
      if (!effectiveIsAudio && !isProtectedPlaylist(playlist)) {
        val items = playlistDao.getPlaylistItems(playlist.id)
        if (items.isNotEmpty()) {
          val hasAudioItems = items.any { app.gyrolet.mpvrx.utils.storage.FileTypeUtils.isAudioFile(java.io.File(it.filePath)) }
          if (hasAudioItems) {
            effectiveIsAudio = true
            playlistDao.updatePlaylist(playlist.copy(isAudio = true))
          }
        }
      }
      if (effectiveIsAudio == targetIsAudio) {
        result.add(playlist)
      }
    }
    return prioritizeFavorites(result)
  }

  suspend fun getPlaylistById(playlistId: Int): PlaylistEntity? = playlistDao.getPlaylistById(playlistId)

  /** Persists the audio flag for playlists whose entries turned out to be audio. */
  suspend fun reclassifyAudioPlaylists() {
    classifyAndFilterPlaylists(playlistDao.getAllPlaylists(), targetIsAudio = true)
  }

  suspend fun removeDeletedZipPlaylists() = withContext(Dispatchers.IO) {
    playlistWriteMutex.withLock {
      for (playlist in playlistDao.getAllPlaylists()) {
        if (!playlist.isZipPlaylist) continue
        val source = ZipArchiveMedia.parseBrowserPath(playlist.m3uSourceUrl.orEmpty())?.archivePath ?: continue
        if (ZipArchiveMedia.sourceDeleted(applicationContext, source)) playlistDao.deletePlaylist(playlist)
      }
    }
  }

  fun observePlaylistById(playlistId: Int): Flow<PlaylistEntity?> = playlistDao.observePlaylistById(playlistId)

  private suspend fun addItemToPlaylistLocked(
    playlistId: Int,
    filePath: String,
    fileName: String,
  ): Boolean {
    if (filePath.isBlank()) return false
    val cleanPath = normalizePlaylistPath(filePath)
    val exists = playlistDao.getPlaylistItems(playlistId).any { isPathMatching(it.filePath, cleanPath) }
    if (exists) return false
    val maxPosition = playlistDao.getMaxPosition(playlistId) ?: -1
    playlistDao.insertPlaylistItem(
      PlaylistItemEntity(
        playlistId = playlistId,
        filePath = cleanPath,
        fileName = fileName,
        position = maxPosition + 1,
        addedAt = System.currentTimeMillis(),
      ),
    )
    getPlaylistById(playlistId)?.let { playlist ->
      updatePlaylist(playlist)
    }
    return true
  }

  suspend fun addItemsToPlaylist(
    playlistId: Int,
    items: List<PlaylistItemInput>,
  ) {
    playlistWriteMutex.withLock {
      if (items.isEmpty()) return@withLock
      val seenPaths = playlistDao.getPlaylistItems(playlistId).mapTo(mutableSetOf()) { playlistPathKey(it.filePath) }
      val uniqueItems =
        items.mapNotNull { input ->
          if (input.filePath.isBlank()) return@mapNotNull null
          val cleanPath = normalizePlaylistPath(input.filePath)
          if (seenPaths.add(playlistPathKey(cleanPath))) input.copy(filePath = cleanPath) else null
        }
      if (uniqueItems.isEmpty()) return@withLock
      val maxPosition = playlistDao.getMaxPosition(playlistId) ?: -1
      val now = System.currentTimeMillis()
      val playlistItems =
        uniqueItems.mapIndexed { index, input ->
          PlaylistItemEntity(
            playlistId = playlistId,
            filePath = input.filePath,
            fileName = input.fileName,
            position = maxPosition + 1 + index,
            addedAt = now,
            fileSize = input.fileSize,
          )
        }
      playlistDao.insertPlaylistItemsAtomically(playlistItems)
      getPlaylistById(playlistId)?.let { playlist ->
        updatePlaylist(playlist)
      }
    }
  }

  suspend fun removeItemsFromPlaylist(items: List<PlaylistItemEntity>) {
    if (items.isEmpty()) return
    playlistDao.deletePlaylistItems(items)
    getPlaylistById(items.first().playlistId)?.let { playlist ->
      updatePlaylist(playlist)
    }
  }

  fun observePlaylistItems(playlistId: Int): Flow<List<PlaylistItemEntity>> =
    playlistDao.observePlaylistItems(playlistId)

  fun observeFirstPlaylistItem(playlistId: Int): Flow<PlaylistItemEntity?> =
    playlistDao.observeFirstPlaylistItem(playlistId)

  fun observePlaylistPreviewItems(playlistId: Int, limit: Int = 2): Flow<List<PlaylistItemEntity>> =
    playlistDao.observePlaylistPreviewItems(playlistId, limit)

  suspend fun getPlaylistItems(playlistId: Int): List<PlaylistItemEntity> = playlistDao.getPlaylistItems(playlistId)

  fun observePlaylistItemCount(playlistId: Int): Flow<Int> = playlistDao.observePlaylistItemCount(playlistId)

  suspend fun getPlaylistItemCount(playlistId: Int): Int = playlistDao.getPlaylistItemCount(playlistId)

  suspend fun reorderPlaylistItems(
    playlistId: Int,
    newOrder: List<Int>,
  ) {
    playlistDao.reorderPlaylistItems(playlistId, newOrder)
    getPlaylistById(playlistId)?.let { playlist ->
      updatePlaylist(playlist)
    }
  }

  // Play history operations
  suspend fun updatePlayHistory(
    playlistId: Int,
    filePath: String,
    position: Long = 0,
  ) {
    playlistDao.updatePlayHistory(playlistId, filePath, System.currentTimeMillis(), position)
  }

  suspend fun getRecentlyPlayedInPlaylist(
    playlistId: Int,
    limit: Int = 20,
  ): List<PlaylistItemEntity> = playlistDao.getRecentlyPlayedInPlaylist(playlistId, limit)

  fun observeRecentlyPlayedInPlaylist(
    playlistId: Int,
    limit: Int = 20,
  ): Flow<List<PlaylistItemEntity>> = playlistDao.observeRecentlyPlayedInPlaylist(playlistId, limit)

  suspend fun getPlaylistItemByPath(
    playlistId: Int,
    filePath: String,
  ): PlaylistItemEntity? = playlistDao.getPlaylistItemByPath(playlistId, filePath)

  // Category / Favorites
  fun observeDistinctCategories(playlistId: Int): Flow<List<String>> = playlistDao.observeDistinctCategories(playlistId)

  suspend fun getDistinctCategories(playlistId: Int): List<String> = playlistDao.getDistinctCategories(playlistId)

  fun observeFavoriteItems(playlistId: Int): Flow<List<PlaylistItemEntity>> =
    playlistDao.observeFavoriteItems(playlistId)

  suspend fun toggleFavorite(itemId: Int) = playlistDao.toggleFavorite(itemId)

  suspend fun setFavorite(
    itemId: Int,
    isFavorite: Boolean,
  ) = playlistDao.setFavorite(itemId, isFavorite)

  // M3U Playlist operations
  suspend fun createM3UPlaylist(
    url: String,
    userAgent: String? = null,
  ): Result<Long> =
    try {
      val remotePlaylist = loadRemotePlaylist(url, userAgent).getOrElse { error -> return Result.failure(error) }
      val playlistId =
        persistM3UPlaylist(
          parseResult = remotePlaylist.parseResult,
          name = remotePlaylist.parseResult.playlistName,
          sourceUrl = remotePlaylist.sourceUrl,
          userAgent = userAgent,
        )
      Result.success(playlistId)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      Result.failure(e)
    }

  suspend fun createXtreamPlaylist(
    serverUrl: String,
    username: String,
    password: String,
  ): Result<Long> =
    try {
      val accountUsername = username
      val catalog =
        xtreamClient
          .loadCatalog(serverUrl, accountUsername, password)
          .getOrElse { error -> return Result.failure(error) }
      val encryptedPassword = encryptXtreamPassword(password)

      remotePlaylistWriteMutex.withLock {
        val existing = playlistDao.getXtreamPlaylistByIdentity(catalog.serverUrl, accountUsername)
        val accountKey = existing?.xtreamAccountKey ?: UUID.randomUUID().toString()
        val securedPlaylist =
          secureXtreamPlaylist(
            parseResult = catalog.playlist,
            accountKey = accountKey,
            username = accountUsername,
            password = password,
          )
        val now = System.currentTimeMillis()

        if (existing != null) {
          replaceRemotePlaylist(
            playlist =
              existing.copy(
                updatedAt = now,
                isM3uPlaylist = true,
                isXtreamPlaylist = true,
                xtreamAccountKey = accountKey,
                xtreamServerUrl = catalog.serverUrl,
                xtreamUsername = accountUsername,
                xtreamEncryptedPassword = encryptedPassword,
              ),
            parseResult = securedPlaylist,
            name = existing.name,
            userAgent = existing.userAgent,
          )
          Result.success(existing.id.toLong())
        } else {
          val host = catalog.serverUrl.toHttpUrlOrNull()?.host ?: "Server"
          val playlist =
            PlaylistEntity(
              name = "Xtream – $host",
              createdAt = now,
              updatedAt = now,
              isM3uPlaylist = true,
              isXtreamPlaylist = true,
              xtreamAccountKey = accountKey,
              xtreamServerUrl = catalog.serverUrl,
              xtreamUsername = accountUsername,
              xtreamEncryptedPassword = encryptedPassword,
            )
          val items =
            securedPlaylist.items.mapIndexed { index, item ->
              item.toEntity(playlistId = 0, position = index, now = now)
            }
          Result.success(playlistDao.insertPlaylistWithItems(playlist, items))
        }
      }
    } catch (error: CancellationException) {
      throw error
    } catch (error: Exception) {
      Result.failure(error)
    }

  suspend fun discoverLocalPlaylists(force: Boolean = false): Unit = withContext(Dispatchers.IO) {
    localPlaylistScanMutex.withLock {
      val seenSources = mutableSetOf<String>()
      val storedSources = playlistDao.getAllPlaylists().mapNotNull { localPlaylistSourceKey(it.m3uSourceUrl) }.toSet()
      LocalPlaylistScanner.scan(applicationContext) { file ->
        val key = LocalPlaylistScanner.sourceKey(applicationContext, file.uri)
        seenSources.add(key)
        if (key in ignoredLocalPlaylistSources()) return@scan true
        val revision = Triple(file.uri.toString(), file.modifiedAt, file.size)
        if (!force && file.modifiedAt > 0L && file.size > 0L && key in storedSources && localPlaylistRevisions[key] == revision) return@scan true
        when (val parsed = M3UParser.parseFromUri(applicationContext, file.uri)) {
          is M3UParseResult.Success -> {
            currentCoroutineContext().ensureActive()
            remotePlaylistWriteMutex.withLock {
              if (key !in ignoredLocalPlaylistSources()) {
                persistM3UPlaylistLocked(parsed, parsed.playlistName, file.uri.toString(), null)
                localPlaylistRevisions[key] = revision
              }
            }
            true
          }
          is M3UParseResult.Error -> M3UParser.shouldPlayHlsDirectly(parsed)
        }
      }
      localPlaylistRevisions.keys.retainAll(seenSources)
    }
  }

  private fun localPlaylistSourceKey(source: String?): String? {
    val uri = source?.let(Uri::parse) ?: return null
    if (uri.scheme != "file" && uri.scheme != "content") return null
    return LocalPlaylistScanner.sourceKey(applicationContext, uri)
  }

  private fun ignoredLocalPlaylistSources(): Set<String> =
    localPlaylistPreferences.getStringSet("ignored_sources", emptySet()).orEmpty().toSet()

  suspend fun createM3UPlaylistFromFile(
    context: Context,
    uri: Uri,
  ): Result<Long> =
    try {
      val parseResult = M3UParser.parseFromUri(context, uri)

      when (parseResult) {
        is M3UParseResult.Success -> {
          val playlistId =
            persistM3UPlaylist(
              parseResult = parseResult,
              name = parseResult.playlistName,
              sourceUrl = uri.toString(),
            )
          Result.success(playlistId)
        }
        is M3UParseResult.Error -> {
          Result.failure(Exception(parseResult.message, parseResult.exception))
        }
      }
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      Result.failure(e)
    }

  /** Persists an already bounded/parsed playlist without materializing and parsing its text again. */
  suspend fun createM3UPlaylistFromParsed(
    parseResult: M3UParseResult.Success,
    sourceName: String,
    sourceUrl: String? = null,
    userAgent: String? = null,
  ): Result<Long> =
    try {
      val playlistId =
        persistM3UPlaylist(
          parseResult = parseResult,
          name = parseResult.playlistName.ifBlank { sourceName.substringBeforeLast('.') },
          sourceUrl = sourceUrl?.let(M3UParser::sanitizeSourceUrl),
          userAgent = userAgent,
        )
      Result.success(playlistId)
    } catch (error: CancellationException) {
      throw error
    } catch (error: Exception) {
      Result.failure(error)
    }

  suspend fun refreshM3UPlaylist(playlistId: Int): Result<Unit> {
    return try {
      val playlist =
        getPlaylistById(playlistId)
          ?: return Result.failure(Exception("Playlist not found"))

      if (playlist.isXtreamPlaylist) {
        return refreshXtreamPlaylist(playlist)
      }

      if (!playlist.isM3uPlaylist || playlist.m3uSourceUrl == null) {
        return Result.failure(Exception("Not an M3U playlist or no source URL available"))
      }

      val sourceUri = Uri.parse(playlist.m3uSourceUrl)
      val parseResult =
        if (sourceUri.scheme == "content" || sourceUri.scheme == "file") {
          when (val result = M3UParser.parseFromUri(applicationContext, sourceUri)) {
            is M3UParseResult.Success -> result
            is M3UParseResult.Error -> return Result.failure(Exception(result.message, result.exception))
          }
        } else {
          loadRemotePlaylist(playlist.m3uSourceUrl, playlist.userAgent)
            .getOrElse { error -> return Result.failure(error) }.parseResult
        }
      remotePlaylistWriteMutex.withLock {
        val currentPlaylist =
          getPlaylistById(playlistId)
            ?: return Result.failure(Exception("Playlist not found"))
        replaceRemotePlaylist(
          playlist = currentPlaylist,
          parseResult = parseResult,
          name = currentPlaylist.name,
          userAgent = playlist.userAgent,
        )
      }
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun resolveXtreamStream(reference: XtreamPlaybackUri.Reference): Result<String> =
    try {
      val playlist =
        playlistDao.getXtreamPlaylistByAccountKey(reference.accountKey)
          ?: return Result.failure(IllegalStateException("Xtream account is unavailable"))
      val serverUrl = playlist.xtreamServerUrl
        ?: return Result.failure(IllegalStateException("Xtream server is unavailable"))
      val username = playlist.xtreamUsername
        ?: return Result.failure(IllegalStateException("Xtream username is unavailable"))
      val password = decryptXtreamPassword(playlist)
      Result.success(XtreamPlaybackUri.resolve(reference, serverUrl, username, password))
    } catch (error: CancellationException) {
      throw error
    } catch (error: Exception) {
      Result.failure(error)
    }

  private suspend fun refreshXtreamPlaylist(playlist: PlaylistEntity): Result<Unit> {
    val serverUrl = playlist.xtreamServerUrl
      ?: return Result.failure(IllegalStateException("Xtream server is unavailable"))
    val username = playlist.xtreamUsername
      ?: return Result.failure(IllegalStateException("Xtream username is unavailable"))
    val accountKey = playlist.xtreamAccountKey
      ?: return Result.failure(IllegalStateException("Xtream account is unavailable"))
    val password =
      runCatching { decryptXtreamPassword(playlist) }
        .getOrElse { error -> return Result.failure(error) }
    val catalog =
      xtreamClient
        .loadCatalog(serverUrl, username, password)
        .getOrElse { error -> return Result.failure(error) }
    val securedPlaylist =
      runCatching {
        secureXtreamPlaylist(catalog.playlist, accountKey, username, password)
      }.getOrElse { error -> return Result.failure(error) }

    return remotePlaylistWriteMutex.withLock {
      val current = getPlaylistById(playlist.id)
        ?: return@withLock Result.failure(IllegalStateException("Playlist not found"))
      if (!current.isXtreamPlaylist || current.xtreamAccountKey != accountKey) {
        return@withLock Result.failure(IllegalStateException("Xtream account changed; refresh again"))
      }
      replaceRemotePlaylist(
        playlist = current.copy(xtreamServerUrl = catalog.serverUrl),
        parseResult = securedPlaylist,
        name = current.name,
        userAgent = current.userAgent,
      )
      Result.success(Unit)
    }
  }

  private fun secureXtreamPlaylist(
    parseResult: M3UParseResult.Success,
    accountKey: String,
    username: String,
    password: String,
  ): M3UParseResult.Success =
    parseResult.copy(
      items =
        parseResult.items.map { item ->
          val reference =
            XtreamPlaybackUri.fromProviderUrl(item.url, accountKey, username, password)
              ?: throw IllegalArgumentException("Xtream catalog contains an unsupported stream URL")
          item.copy(
            url = XtreamPlaybackUri.create(reference),
            title = scrubXtreamPassword(item.title, password),
            tvgId = scrubXtreamPassword(item.tvgId, password),
            tvgName = scrubXtreamPassword(item.tvgName, password),
            tvgLogo = sanitizeXtreamUrlMetadata(item.tvgLogo, password),
            groupTitle = scrubXtreamPassword(item.groupTitle, password),
            licenseType = scrubXtreamPassword(item.licenseType, password),
            licenseKey = sanitizeXtreamUrlMetadata(item.licenseKey, password),
            userAgent = scrubXtreamPassword(item.userAgent, password),
          )
        },
    )

  private fun encryptXtreamPassword(password: String): String =
    try {
      credentialCipher.encrypt(password)
    } catch (error: Exception) {
      throw NetworkCredentialStorageException(error)
    }

  private fun decryptXtreamPassword(playlist: PlaylistEntity): String {
    val encrypted = playlist.xtreamEncryptedPassword
      ?: throw IllegalStateException("Saved Xtream password is unavailable. Add the account again.")
    return try {
      credentialCipher.decrypt(encrypted)
    } catch (_: Exception) {
      throw IllegalStateException("Saved Xtream password is unavailable. Add the account again.")
    }
  }

  private fun sanitizeXtreamUrlMetadata(
    value: String?,
    password: String,
  ): String? =
    value?.takeUnless { candidate ->
      containsSecret(candidate, password)
    }

  private fun containsSecret(
    value: String,
    secret: String,
  ): Boolean {
    if (secret.isBlank()) return false
    if (value.contains(secret)) return true
    val decoded = runCatching { URLDecoder.decode(value, StandardCharsets.UTF_8.name()) }.getOrDefault(value)
    return decoded.contains(secret)
  }

  private fun scrubXtreamPassword(
    value: String?,
    password: String,
  ): String? = value?.replace(password, "•••")

  private suspend fun persistM3UPlaylist(
    parseResult: M3UParseResult.Success,
    name: String,
    sourceUrl: String?,
    userAgent: String? = null,
  ): Long = withContext(Dispatchers.IO) {
    remotePlaylistWriteMutex.withLock {
      persistM3UPlaylistLocked(parseResult, name, sourceUrl, userAgent)
    }
  }

  private suspend fun persistM3UPlaylistLocked(
    parseResult: M3UParseResult.Success,
    name: String,
    sourceUrl: String?,
    userAgent: String?,
  ): Long {
    val now = System.currentTimeMillis()
    val localSourceKey = localPlaylistSourceKey(sourceUrl)
    val localCandidates = if (localSourceKey != null) {
      playlistDao.getAllPlaylists().filter { it.isM3uPlaylist && !it.isXtreamPlaylist }
    } else emptyList()
    val existingPlaylist = sourceUrl?.let { playlistDao.getRemotePlaylistBySourceUrl(it) }
      ?: localSourceKey?.let { key ->
        localCandidates.firstOrNull { localPlaylistSourceKey(it.m3uSourceUrl) == key }
      }
      ?: localCandidates.firstOrNull { candidate ->
        if (candidate.m3uSourceUrl != null || candidate.name != name) {
          false
        } else {
          val items = playlistDao.getPlaylistItems(candidate.id)
          items.size == parseResult.items.size && items.withIndex().all { (index, item) ->
            M3UParser.normalizeLocalMediaReference(item.filePath) == M3UParser.normalizeLocalMediaReference(parseResult.items[index].url)
          }
        }
      }
    val playlistId = if (existingPlaylist != null) {
      replaceRemotePlaylist(
        playlist = existingPlaylist.copy(m3uSourceUrl = sourceUrl),
        parseResult = parseResult,
        name = existingPlaylist.name,
        userAgent = userAgent ?: existingPlaylist.userAgent,
      )
      existingPlaylist.id.toLong()
    } else {
      val playlist =
        PlaylistEntity(
          name = name,
          createdAt = now,
          updatedAt = now,
          m3uSourceUrl = sourceUrl,
          isM3uPlaylist = true,
          userAgent = userAgent,
        )
      val items =
        parseResult.items.mapIndexed { index, item ->
          item.toEntity(playlistId = 0, position = index, now = now)
        }
      playlistDao.insertPlaylistWithItems(playlist, items)
    }
    if (localSourceKey != null) {
      val ignored = ignoredLocalPlaylistSources()
      if (localSourceKey in ignored) {
        localPlaylistPreferences.edit().putStringSet("ignored_sources", ignored - localSourceKey).apply()
      }
    }
    return playlistId
  }

  private suspend fun replaceRemotePlaylist(
    playlist: PlaylistEntity,
    parseResult: M3UParseResult.Success,
    name: String,
    userAgent: String?,
  ) {
    val previousItems =
      playlistDao
        .getPlaylistItems(playlist.id)
        .associateBy { item -> M3UParser.normalizeLocalMediaReference(item.filePath) }
    val previousItemsByTvgId =
      previousItems.values
        .filter { item -> !item.tvgId.isNullOrBlank() }
        .associateBy { item -> item.tvgId }
    val previousXtreamItems =
      previousItems.values.mapNotNull { item ->
        xtreamItemIdentity(item.filePath)?.let { identity -> identity to item }
      }.toMap()
    val now = System.currentTimeMillis()
    val items =
      parseResult.items.mapIndexed { index, item ->
        val normalizedPath = M3UParser.normalizeLocalMediaReference(item.url)
        item.toEntity(
          playlistId = playlist.id,
          position = index,
          now = now,
          previousItem =
            previousItems[normalizedPath]
              ?: xtreamItemIdentity(normalizedPath)?.let(previousXtreamItems::get)
              ?: item.tvgId?.let(previousItemsByTvgId::get),
        )
      }
    playlistDao.replacePlaylistItems(
      playlist.copy(name = name, updatedAt = now, userAgent = userAgent),
      items,
    )
  }

  private suspend fun loadRemotePlaylist(
    sourceUrl: String,
    userAgent: String?,
  ): Result<RemotePlaylist> {
    var webPlaylistError: Throwable? = null
    if (YtdlpManager.isPotentialPlaylistUrl(sourceUrl) && YtdlpManager.requiresYtdlp(sourceUrl)) {
      val webPlaylistResult =
        YtdlpManager
        .extractPlaylist(applicationContext, sourceUrl, ytdlPreferences, userAgentOverride = userAgent)
        .map { playlist ->
          RemotePlaylist(
            parseResult = playlist.toM3UParseResult(),
            sourceUrl = playlist.sourceUrl,
          )
        }
      webPlaylistResult.getOrNull()?.let { playlist -> return Result.success(playlist) }
      webPlaylistError = webPlaylistResult.exceptionOrNull()
      if (HttpUtils.isYouTubeUrl(Uri.parse(sourceUrl))) {
        return Result.failure(webPlaylistError ?: IllegalStateException("Failed to read YouTube playlist"))
      }
    }

    return when (val parseResult = M3UParser.parseFromUrl(sourceUrl, userAgent, httpClient = httpClient)) {
      is M3UParseResult.Success ->
        Result.success(
          RemotePlaylist(
            parseResult = parseResult,
            sourceUrl = M3UParser.sanitizeSourceUrl(sourceUrl),
          ),
        )
      is M3UParseResult.Error ->
        Result.failure(webPlaylistError ?: Exception(parseResult.message, parseResult.exception))
    }
  }
}

private data class RemotePlaylist(
  val parseResult: M3UParseResult.Success,
  val sourceUrl: String,
)

private fun YtdlpPlaylistMetadata.toM3UParseResult(): M3UParseResult.Success =
  M3UParseResult.Success(
    playlistName = title,
    items =
      entries.map { entry ->
        M3UPlaylistItem(
          url = entry.url,
          title = entry.title,
          duration = entry.durationSeconds,
          tvgId = entry.id,
          tvgLogo = entry.thumbnailUrl,
          groupTitle = entry.artist,
        )
      },
  )

private fun M3UPlaylistItem.toEntity(
  playlistId: Int,
  position: Int,
  now: Long,
  previousItem: PlaylistItemEntity? = null,
): PlaylistItemEntity =
  PlaylistItemEntity(
    playlistId = playlistId,
    filePath = M3UParser.normalizeLocalMediaReference(url),
    fileName = title ?: tvgName ?: url.substringAfterLast('/').take(80).ifBlank { "Item ${position + 1}" },
    position = position,
    addedAt = previousItem?.addedAt ?: now,
    lastPlayedAt = previousItem?.lastPlayedAt ?: 0,
    playCount = previousItem?.playCount ?: 0,
    lastPosition = previousItem?.lastPosition ?: 0,
    tvgId = tvgId,
    tvgLogo = tvgLogo,
    groupTitle = groupTitle,
    licenseType = licenseType,
    licenseKey = licenseKey,
    userAgent = userAgent,
    isFavorite = previousItem?.isFavorite ?: false,
  )

private fun xtreamItemIdentity(uri: String): String? =
  XtreamPlaybackUri.parse(uri)?.let { reference ->
    "${reference.accountKey}:${reference.route.wireValue}:${reference.streamId}"
  }
