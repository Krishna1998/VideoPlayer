/*
 * SPDX-License-Identifier: AGPL-3.0-or-later
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

package app.gyrolet.mpvrx.repository.ai

import app.gyrolet.mpvrx.network.awaitResponse
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody

@Serializable
private data class OpenAiModel(
  val id: String,
  val pricing: JsonObject? = null,
)

@Serializable
private data class OpenAiModelListResponse(
  val data: List<OpenAiModel> = emptyList(),
)

@Serializable
private data class OpenAiMessage(
  val role: String,
  val content: String,
)

@Serializable
private data class OpenAiErrorBody(
  val error: OpenAiErrorDetail? = null,
)

@Serializable
private data class OpenAiErrorDetail(
  val message: String? = null,
)

@Serializable
private data class OpenAiChatRequest(
  val model: String,
  val messages: List<OpenAiMessage>,
  val temperature: Double? = null,
  @SerialName("max_completion_tokens") val maxCompletionTokens: Int = 200,
)

class OpenAiClient(
  private val client: OkHttpClient,
  private val json: Json,
) : AiClient {
  companion object {
    private const val BASE_URL = "https://api.openai.com/v1"
    private val JSON_MEDIA_TYPE = "application/json".toMediaType()
  }

  private val apiClient: OkHttpClient =
    client.withAiChatTimeouts()

  override suspend fun fetchModels(apiKey: String): Result<List<AiModelInfo>> =
    withContext(Dispatchers.IO) {
      runCatchingCancellable {
        val request =
          bearerGetRequest("$BASE_URL/models", apiKey)

        apiClient.newCall(request).awaitResponse().use { response ->
          val body = response.body.string()
          if (!response.isSuccessful) throw Exception("OpenAI API error ${response.code}: ${parseError(body)}")

          val parsed = json.decodeFromString<OpenAiModelListResponse>(body)
          parsed.data.map { model ->
            AiModelInfo(
              id = model.id,
              displayName = model.id,
              isFree = AiModelPricing.isZeroCost(model.pricing),
            )
          }
        }
      }
    }

  override suspend fun verifyKey(apiKey: String): Result<String> =
    withContext(Dispatchers.IO) {
      runCatchingCancellable {
        val request =
          bearerGetRequest("$BASE_URL/models", apiKey)

        apiClient.newCall(request).awaitResponse().use { response ->
          if (!response.isSuccessful) throw Exception("Invalid API key: ${response.code}")
          "API key verified successfully"
        }
      }
    }

  override suspend fun generateContent(
    apiKey: String,
    model: String,
    instruction: String,
    userInput: String,
    options: AiGenerationOptions,
  ): Result<AiGeneratedContent> =
    withContext(Dispatchers.IO) {
      runCatchingCancellable {
        val requestBody =
          json.encodeToString(
            OpenAiChatRequest.serializer(),
            OpenAiChatRequest(
              model = model,
              messages =
                listOf(
                  OpenAiMessage(role = if (isReasoningModel(model)) "developer" else "system", content = instruction),
                  OpenAiMessage(role = "user", content = userInput),
                ),
              temperature = options.temperature.takeUnless { isReasoningModel(model) },
              maxCompletionTokens = options.maxTokens,
            ),
          )

        val request =
          Request
            .Builder()
            .url("$BASE_URL/chat/completions")
            .header("Authorization", "Bearer $apiKey")
            .post(requestBody.toRequestBody(JSON_MEDIA_TYPE))
            .build()

        apiClient.newCall(request).awaitResponse().use { response ->
          val body = response.body.string()
          if (!response.isSuccessful) throw Exception("OpenAI generate error ${response.code}: ${parseError(body)}")
          AiResponseParser.openAiCompatible(json, body, "OpenAI")
        }
      }
    }

  private fun parseError(body: String): String =
    try {
      val error = json.decodeFromString<OpenAiErrorBody>(body)
      error.error?.message ?: body
    } catch (_: Exception) {
      body.take(200)
    }

  private fun isReasoningModel(model: String): Boolean {
    val id = model.substringAfterLast('/').lowercase()
    return id.matches(Regex("^o\\d.*")) ||
      id.matches(Regex("^gpt-[5-9].*")) ||
      id.contains("reasoning") ||
      id.contains("codex")
  }
}
