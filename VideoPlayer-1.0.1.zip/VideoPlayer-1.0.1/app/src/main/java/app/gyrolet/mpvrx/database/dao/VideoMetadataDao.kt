/*
 * SPDX-License-Identifier: AGPL-3.0-or-later
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

package app.gyrolet.mpvrx.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import app.gyrolet.mpvrx.database.entities.VideoMetadataEntity

@Dao
interface VideoMetadataDao {
  /**
   * Get cached metadata for a video
   * Returns null if not cached or cache is stale (file was modified after cache entry)
   */
  @Query(
    """
    SELECT * FROM video_metadata_cache 
    WHERE path = :path 
    AND dateModified = :dateModified 
    AND size = :size
    LIMIT 1
    """,
  )
  suspend fun getMetadata(
    path: String,
    dateModified: Long,
    size: Long,
  ): VideoMetadataEntity?

  /**
   * Get cached metadata for multiple videos at once
   */
  @Query("SELECT * FROM video_metadata_cache WHERE path IN (:paths)")
  suspend fun getMetadataBatch(paths: List<String>): List<VideoMetadataEntity>

  /**
   * Insert or update cached metadata
   */
  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertMetadata(metadata: VideoMetadataEntity)

  /**
   * Insert multiple metadata entries at once
   */
  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertMetadataBatch(metadata: List<VideoMetadataEntity>)

  /**
   * Clear old cache entries (older than 30 days)
   */
  @Query("DELETE FROM video_metadata_cache WHERE lastScanned < :cutoffTimestamp")
  suspend fun clearOldCache(cutoffTimestamp: Long)

  /**
   * Clear all cached metadata
   */
  @Query("DELETE FROM video_metadata_cache")
  suspend fun clearAll()

  /**
   * Get total number of cached entries
   */
  @Query("SELECT COUNT(*) FROM video_metadata_cache")
  suspend fun getCacheCount(): Int

  /**
   * Delete multiple cache entries by paths
   */
  @Query("DELETE FROM video_metadata_cache WHERE path IN (:paths)")
  suspend fun deleteByPaths(paths: List<String>)

  /**
   * Get all cached paths (for validating existence)
   */
  @Query("SELECT path FROM video_metadata_cache")
  suspend fun getAllCachedPaths(): List<String>

  /**
   * Get cache size in bytes (approximate)
   */
  @Query("SELECT SUM(size) FROM video_metadata_cache")
  suspend fun getTotalCacheSize(): Long?

}
