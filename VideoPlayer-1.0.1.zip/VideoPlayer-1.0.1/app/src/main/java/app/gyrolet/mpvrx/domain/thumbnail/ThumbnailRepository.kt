/*
 * SPDX-License-Identifier: AGPL-3.0-or-later
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

package app.gyrolet.mpvrx.domain.thumbnail

import android.app.ActivityManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.SystemClock
import android.provider.MediaStore
import android.util.LruCache
import app.gyrolet.mpvrx.utils.memory.BitmapMemoryCache
import app.gyrolet.mpvrx.data.network.client.NetworkMimeTypes
import app.gyrolet.mpvrx.data.network.proxy.NetworkStreamingProxy
import app.gyrolet.mpvrx.domain.archive.ZipArchiveMedia
import app.gyrolet.mpvrx.domain.media.model.Video
import app.gyrolet.mpvrx.domain.network.NetworkConnection
import app.gyrolet.mpvrx.preferences.ThumbnailGenerator
import app.gyrolet.mpvrx.preferences.ThumbnailMode
import app.gyrolet.mpvrx.repository.NetworkRepository
import app.gyrolet.mpvrx.ui.player.resolveLocalPath
import `is`.xyz.mpv.FastThumbnails
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlinx.coroutines.yield
import org.koin.java.KoinJavaComponent
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.locks.ReentrantReadWriteLock
import kotlin.concurrent.read
import kotlin.concurrent.write
import kotlin.math.max
import kotlin.math.roundToInt

private const val NETWORK_THUMBNAIL_FAILURE_RETRY_MS = 30_000L
private const val LOCAL_THUMBNAIL_FAILURE_RETRY_MS = 60_000L
private const val AUDIO_ARTWORK_SMALL_TIER_PX = 256
private const val IDENTITY_CACHE_TTL_MS = 30_000L

private val LOWER_HEX_DIGITS = "0123456789abcdef".toCharArray()

// Same text as joinToString { "%02x".format(it) } (cache file names depend on it), without a
// Formatter per byte on every disk-cache lookup.
private fun ByteArray.toLowerHex(): String {
  val chars = CharArray(size * 2)
  for (index in indices) {
    val value = this[index].toInt() and 0xff
    chars[index * 2] = LOWER_HEX_DIGITS[value ushr 4]
    chars[index * 2 + 1] = LOWER_HEX_DIGITS[value and 0x0f]
  }
  return String(chars)
}

class ThumbnailRepository(
  private val context: Context,
) {
  internal val artworkContext: Context get() = context
  private val appearancePreferences by lazy {
    KoinJavaComponent.get<app.gyrolet.mpvrx.preferences.AppearancePreferences>(
      app.gyrolet.mpvrx.preferences.AppearancePreferences::class.java,
    )
  }
  private val browserPreferences by lazy {
    KoinJavaComponent.get<app.gyrolet.mpvrx.preferences.BrowserPreferences>(
      app.gyrolet.mpvrx.preferences.BrowserPreferences::class.java,
    )
  }
  private val networkRepository by lazy {
    KoinJavaComponent.get<NetworkRepository>(NetworkRepository::class.java)
  }

  private val memoryCache = BitmapMemoryCache<String>(heapDivisor = 8, maxSizeMiB = 48)
  private val localDiskDir = File(context.filesDir, "thumbnails/local").apply { mkdirs() }
  private val networkDiskDir = File(context.filesDir, "thumbnails/network").apply { mkdirs() }
  private val diskCacheLock = ReentrantReadWriteLock()
  private val _cacheRevision = MutableStateFlow(0L)
  val cacheRevision = _cacheRevision.asStateFlow()
  private val ongoingOperations = ConcurrentHashMap<String, Deferred<Bitmap?>>()
  private data class CachedIdentity<T>(val value: T, val savedAtMs: Long = SystemClock.elapsedRealtime()) {
    fun isFresh(): Boolean = SystemClock.elapsedRealtime() - savedAtMs < IDENTITY_CACHE_TTL_MS
  }
  private val diskVideoBaseKeyCache = LruCache<String, CachedIdentity<String>>(2048)
  // Lets composition reuse keys already computed on worker threads.
  private val resolvedThumbnailKeys = LruCache<String, String>(4096)
  private data class ResolvedMetadata(
    val size: Long,
    val dateModified: Long,
    val duration: Long,
  )
  private val localMetadataCache = LruCache<String, CachedIdentity<ResolvedMetadata>>(2048)
  private val repositoryScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
  private val maxConcurrentFolders = 3

  /** Device default used when the setting is Auto: 1 on low-end devices, otherwise 2. */
  internal val automaticParallelism: Int by lazy { resolveLocalGenerationParallelism() }

  // Permits cannot be resized, so a changed setting swaps in new semaphores. Work already holding a
  // permit finishes on the old ones, and new requests follow the new limit.
  private class WorkLimits(val parallelism: Int) {
    val generation = Semaphore(parallelism)
    // Cached JPEG decoding is CPU/memory work too; Dispatchers.IO alone allows dozens at once.
    val cachedReads = Semaphore(parallelism)
  }

  @Volatile private var workLimits: WorkLimits? = null

  @Synchronized
  private fun currentWorkLimits(): WorkLimits {
    val wanted = effectiveThumbnailParallelism(browserPreferences.thumbnailParallelism.get(), automaticParallelism)
    workLimits?.takeIf { it.parallelism == wanted }?.let { return it }
    return WorkLimits(wanted).also { workLimits = it }
  }

  private val networkGenerationSemaphore = Semaphore(1)
  private val maxFolderBatchSize = 12

  private data class FolderState(
    val signature: String,
    @Volatile var nextIndex: Int = 0,
  )

  private val folderStates = ConcurrentHashMap<String, FolderState>()
  private val folderJobs = ConcurrentHashMap<String, Job>()

  // Throttle transient failures while still allowing remote files to recover during this process.
  private val networkThumbnailFailedAt = LruCache<String, Long>(256)
  // Bounded, versioned negative cache: a broken local file must not be decoded on every scroll.
  private val localThumbnailFailedAt = LruCache<String, Long>(256)

  private val _thumbnailReadyKeys =
    MutableSharedFlow<String>(
      extraBufferCapacity = 256,
    )
  val thumbnailReadyKeys: SharedFlow<String> = _thumbnailReadyKeys.asSharedFlow()

  suspend fun getThumbnail(
    video: Video,
    widthPx: Int,
    heightPx: Int,
  ): Bitmap? =
    withContext(Dispatchers.IO) {
      val (revision, generator) = diskCacheLock.read { cacheRevision.value to browserPreferences.thumbnailGenerator.get() }
      // Refresh sidecar identity on a worker before consulting the bitmap cache. Composition
      // only peeks at already-resolved keys and never stats artwork files.
      diskVideoBaseKey(video)
      val key = thumbnailKey(video, widthPx, heightPx, generator)
      val operationKey = "$key|revision:$revision"

      if (isNetworkUrl(video.path) && !isNetworkThumbnailAllowed(video.path)) {
        return@withContext null
      }

      synchronized(memoryCache) {
        memoryCache.get(key)
      }?.let { return@withContext it }

      ongoingOperations[operationKey]?.let { return@withContext it.await() }

      val candidate =
        async(start = CoroutineStart.LAZY) {
          if (revision != cacheRevision.value) return@async null
          getCachedThumbnail(video, widthPx, heightPx, generator)?.let { cached ->
            diskCacheLock.read {
              if (revision != cacheRevision.value) return@async null
              synchronized(memoryCache) { memoryCache.put(key, cached) }
            }
            _thumbnailReadyKeys.tryEmit(key)
            return@async cached
          }

          // Check disk first so a valid thumbnail remains usable even after an earlier failure.
          // The key includes file identity and thumbnail settings, so edits/mode changes retry.
          val artworkTier = audioArtworkTier(video, widthPx, heightPx)
          val diskKey = diskCacheKey(video, generator, artworkTier)
          val localFailureKey = if (isNetworkUrl(video.path)) null else diskKey
          if (localFailureKey != null && hasRecentLocalThumbnailFailure(localFailureKey)) {
            return@async null
          }

          val generated =
            when {
              isHttpUrl(video.path) ->
                networkGenerationSemaphore.withPermit {
                  getOrCreateNetworkVideoThumbnail(video, widthPx, heightPx)
                }
              isNetworkUrl(video.path) -> null
              else ->
                currentWorkLimits().generation.withPermit {
                  generateLocalThumbnail(video, widthPx, heightPx, generator, artworkTier)
                }
            } ?: run {
              // Cancellation is not a decoder failure and must never poison the cache.
              currentCoroutineContext().ensureActive()
              if (localFailureKey != null) {
                synchronized(localThumbnailFailedAt) {
                  localThumbnailFailedAt.put(localFailureKey, SystemClock.elapsedRealtime())
                }
              }
              return@async null
            }

          currentCoroutineContext().ensureActive()
          if (localFailureKey != null) {
            synchronized(localThumbnailFailedAt) { localThumbnailFailedAt.remove(localFailureKey) }
          }
          // Audio art is generated at its cache tier; store that before scaling to this request.
          writeBitmapToDisk(diskKey, generated, isNetworkUrl(video.path), revision)
          val bitmap = scaleBitmap(generated, widthPx, heightPx)
          bitmap.prepareToDraw()
          diskCacheLock.read {
            if (revision != cacheRevision.value) return@async null
            synchronized(memoryCache) { memoryCache.put(key, bitmap) }
          }
          _thumbnailReadyKeys.tryEmit(key)
          bitmap
        }

      val operation =
        ongoingOperations.putIfAbsent(operationKey, candidate)?.also {
          candidate.cancel()
        } ?: candidate.also { owned ->
          owned.invokeOnCompletion {
            ongoingOperations.remove(operationKey, owned)
          }
          owned.start()
        }

      operation.await()
    }

  private fun hasRecentLocalThumbnailFailure(key: String): Boolean =
    synchronized(localThumbnailFailedAt) {
      val failedAt = localThumbnailFailedAt.get(key) ?: return@synchronized false
      val recent = SystemClock.elapsedRealtime() - failedAt < LOCAL_THUMBNAIL_FAILURE_RETRY_MS
      if (!recent) localThumbnailFailedAt.remove(key)
      recent
    }

  suspend fun getCachedThumbnail(
    video: Video,
    widthPx: Int,
    heightPx: Int,
    generator: ThumbnailGenerator = browserPreferences.thumbnailGenerator.get(),
  ): Bitmap? =
    withContext(Dispatchers.IO) {
      val revision = diskCacheLock.read { cacheRevision.value }
      currentWorkLimits().cachedReads.withPermit {
        if (isNetworkUrl(video.path) && !isNetworkThumbnailAllowed(video.path)) {
          return@withPermit null
        }

        // Recheck after acquiring a permit: another request may have populated memory meanwhile.
        diskVideoBaseKey(video)
        val key = thumbnailKey(video, widthPx, heightPx, generator)
        synchronized(memoryCache) {
          memoryCache.get(key)
        }?.let { return@withPermit it }

        val isNetwork = isNetworkUrl(video.path)
        val artworkTier = audioArtworkTier(video, widthPx, heightPx)
        val fullColor = artworkTier > 0
        var decoded = readBitmapFromDisk(diskCacheKey(video, generator, artworkTier), isNetwork, widthPx, heightPx, fullColor)
        if (decoded == null && !isNetwork) {
          if (video.duration > 0L) {
            decoded =
              readBitmapFromDisk(
                diskCacheKey(video.copy(duration = 0L), generator, artworkTier), false, widthPx, heightPx, fullColor,
              )
          } else {
            val canonical = canonicalLocalPath(video)
            val resolvedDur = resolveLocalMetadata(video, canonical).duration
            if (resolvedDur > 0L) {
              decoded =
                readBitmapFromDisk(
                  diskCacheKey(video.copy(duration = resolvedDur), generator, artworkTier), false, widthPx, heightPx, fullColor,
                )
            }
          }
        }
        if (decoded == null) return@withPermit null

        val scaled = scaleBitmap(decoded, widthPx, heightPx)
        currentCoroutineContext().ensureActive()
        scaled.prepareToDraw()
        diskCacheLock.read {
          if (revision != cacheRevision.value) return@withPermit null
          synchronized(memoryCache) { memoryCache.put(key, scaled) }
        }
        scaled
      }
    }

  /** Cheap cold-start gate for Folder/Tree roots: do not enumerate folder contents
   * when there are no cached thumbnails to display. Call from a worker thread. */
  fun hasLocalCachedThumbnails(): Boolean = !localDiskDir.list().isNullOrEmpty()

  /** Inspect the same cache identities used by the browser, without opening a media decoder. */
  internal suspend fun inspectThumbnail(video: Video): ThumbnailInspection =
    withContext(Dispatchers.IO) {
      val network = isNetworkUrl(video.path)
      val generator = browserPreferences.thumbnailGenerator.get()
      val quality = browserPreferences.thumbnailQuality.get()
      val indexedVideo = if (network) {
        video
      } else {
        // Prefer the browser's indexed identity when the report's duration is rounded differently.
        val metadata = resolveLocalMetadata(video.copy(duration = 0L), canonicalLocalPath(video))
        video.copy(
          size = metadata.size,
          dateModified = metadata.dateModified,
          duration = metadata.duration.takeIf { it > 0L } ?: video.duration,
        )
      }
      val identities = listOf(indexedVideo, video, video.copy(duration = 0L)).distinct()
      val artworkTiers =
        if (!network && isAudioArtwork(video)) {
          listOf(thumbnailMaxSize(), MAX_THUMBNAIL_SIZE, AUDIO_ARTWORK_SMALL_TIER_PX).distinct()
        } else {
          listOf(0)
        }
      val diskKeys =
        identities.flatMap { identity -> artworkTiers.map { tier -> diskCacheKey(identity, generator, tier) } }.toMutableList()
      if (network) diskKeys += networkThumbnailDiskKey(networkThumbnailIdentity(video.path, null))
      val bases = identities.map { "${diskVideoBaseKey(it)}|" }
      val suffix = "|${thumbnailModeKey()}|${thumbnailQualityKey()}" + thumbnailGeneratorCacheKey(video, generator)
      val memoryBitmap = synchronized(memoryCache) {
        memoryCache.snapshot().entries.firstOrNull { (key, bitmap) ->
          !bitmap.isRecycled && bases.any { base -> key.startsWith(base) } && key.endsWith(suffix)
        }?.value
      }
      val diskEntry = diskCacheLock.read {
        val entries = diskKeys.distinct().mapNotNull { key ->
          val file = File(if (network) networkDiskDir else localDiskDir, keyToFileName(key))
          if (!file.isFile) return@mapNotNull null
          val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
          runCatching { BitmapFactory.decodeFile(file.absolutePath, bounds) }
          Triple(key, file, bounds)
        }
        entries.firstOrNull { (_, _, bounds) -> bounds.outWidth > 0 && bounds.outHeight > 0 } ?: entries.firstOrNull()
      }
      val diskPreview = diskEntry?.let { (key, _, _) -> readBitmapFromDisk(key, network) }
      val preview = diskPreview ?: memoryBitmap
      val bounds = diskEntry?.third
      val file = diskEntry?.second
      ThumbnailInspection(
        cacheVideo = indexedVideo,
        preview = preview,
        generator = if (network) ThumbnailGenerator.Native else generator,
        mode = browserPreferences.thumbnailMode.get(),
        quality = quality,
        framePositionPercent = browserPreferences.thumbnailFramePosition.get(),
        width = bounds?.outWidth?.takeIf { it > 0 } ?: preview?.width,
        height = bounds?.outHeight?.takeIf { it > 0 } ?: preview?.height,
        mimeType = bounds?.outMimeType,
        filePath = file?.absolutePath,
        fileSizeBytes = file?.length(),
        modifiedAtMillis = file?.lastModified()?.takeIf { it > 0 },
        cachedInMemory = memoryBitmap != null,
        jpegEncoderQuality = THUMBNAIL_JPEG_QUALITY,
      )
    }

  fun getThumbnailFromMemory(
    video: Video,
    widthPx: Int,
    heightPx: Int,
  ): Bitmap? {
    if (isNetworkUrl(video.path) && !isNetworkThumbnailAllowed(video.path)) {
      return null
    }

    return peekThumbnailFromMemory(video, widthPx, heightPx)
  }

  /** Publish the new generator only after the old cache has been removed. */
  suspend fun setThumbnailGenerator(generator: ThumbnailGenerator) = withContext(Dispatchers.IO) {
    if (browserPreferences.thumbnailGenerator.get() != generator) resetThumbnailCache(generator)
  }

  fun clearThumbnailCache() = resetThumbnailCache()

  private fun resetThumbnailCache(generator: ThumbnailGenerator? = null) = diskCacheLock.write {
    folderJobs.values.forEach { it.cancel() }
    folderJobs.clear()
    folderStates.clear()
    ongoingOperations.values.forEach { it.cancel() }
    ongoingOperations.clear()
    // Cancelled native work can still hold its old permit until its decoder returns.
    workLimits = null
    diskVideoBaseKeyCache.evictAll()
    resolvedThumbnailKeys.evictAll()
    localMetadataCache.evictAll()
    networkThumbnailFailedAt.evictAll()
    synchronized(localThumbnailFailedAt) { localThumbnailFailedAt.evictAll() }

    synchronized(memoryCache) {
      memoryCache.evictAll()
    }

    try {
      listOf(
        File(context.cacheDir, "thumbnails"),
        File(context.filesDir, "thumbnails"),
        File(context.cacheDir, "remote_images"),
        File(context.cacheDir, "network_images"),
      ).forEach(::deleteCacheDirectory)
      check(localDiskDir.mkdirs() || localDiskDir.isDirectory) {
        "Unable to recreate thumbnail cache directory: ${localDiskDir.absolutePath}"
      }
      check(networkDiskDir.mkdirs() || networkDiskDir.isDirectory) {
        "Unable to recreate thumbnail cache directory: ${networkDiskDir.absolutePath}"
      }
      // NetworkImageRepository owns this directory but is a Koin singleton, so its mkdirs() only
      // ever ran once at construction. Recreate it here or every network image load silently fails
      // until the process restarts.
      File(context.cacheDir, "network_images").mkdirs()
      if (generator != null) browserPreferences.thumbnailGenerator.set(generator)
    } finally {
      // Visible song/video/folder covers and playback artwork discard their own retained bitmaps.
      _cacheRevision.value += 1L
    }
  }

  private fun deleteCacheDirectory(directory: File) {
    if (directory.exists() && !directory.deleteRecursively()) {
      error("Unable to clear cache directory: ${directory.absolutePath}")
    }
  }

  fun startFolderThumbnailGeneration(
    folderId: String,
    videos: List<Video>,
    widthPx: Int,
    heightPx: Int,
  ) {
    val videoSequence = videos.asSequence()
    val filteredVideos =
      (
        if (appearancePreferences.showNetworkThumbnails.get()) {
          videoSequence
        } else {
          videoSequence.filterNot { isNetworkUrl(it.path) }
        }
      ).take(maxFolderBatchSize)
        .toList()

    if (filteredVideos.isEmpty()) {
      return
    }

    folderJobs.entries.removeAll { !it.value.isActive }

    if (folderJobs.size >= maxConcurrentFolders && !folderJobs.containsKey(folderId)) {
      folderJobs.entries.firstOrNull()?.let { (oldestId, job) ->
        job.cancel()
        folderJobs.remove(oldestId)
        folderStates.remove(oldestId)
      }
    }

    val signature = folderSignature(filteredVideos, widthPx, heightPx)
    val existingState = folderStates[folderId]
    val state =
      folderStates.compute(folderId) { _, existing ->
        if (existing == null || existing.signature != signature) {
          FolderState(signature = signature, nextIndex = 0)
        } else {
          existing
        }
      }!!

    val existingJob = folderJobs[folderId]
    val shouldRestart =
      existingState == null ||
        existingState.signature != signature ||
        (existingJob?.isActive != true && state.nextIndex < filteredVideos.size)

    // Keep an active matching batch, but resume one that was cancelled before completing.
    if (shouldRestart) {
      folderJobs.remove(folderId)?.cancel()
      folderJobs[folderId] =
        repositoryScope.launch {
          var i = state.nextIndex
          while (i < filteredVideos.size) {
            val batchEnd = (i + currentWorkLimits().parallelism).coerceAtMost(filteredVideos.size)
            coroutineScope {
              (i until batchEnd)
                .map { index ->
                  async {
                    getThumbnail(filteredVideos[index], widthPx, heightPx)
                  }
                }.awaitAll()
            }
            i = batchEnd
            state.nextIndex = i
            yield()
          }
        }
    }
  }

  /** Pause bulk generation during a fling without discarding completed batches. */
  fun pauseFolderThumbnailGeneration(folderId: String) {
    folderJobs.remove(folderId)?.cancel()
  }

  /** Discard progress when the folder screen is disposed. */
  fun cancelFolderThumbnailGeneration(folderId: String) {
    pauseFolderThumbnailGeneration(folderId)
    folderStates.remove(folderId)
  }

  fun thumbnailKey(
    video: Video,
    width: Int,
    height: Int,
    generator: ThumbnailGenerator = browserPreferences.thumbnailGenerator.get(),
  ): String =
    ("${memoryVideoBaseKey(video)}|$width|$height|${thumbnailModeKey()}|${thumbnailQualityKey()}" +
      thumbnailGeneratorCacheKey(video, generator)).also { key ->
      resolvedThumbnailKeys.put(peekIdentity(video, width, height, generator), key)
    }

  /**
   * Non-blocking peek for composition. Building a key can hit the filesystem or MediaStore, so this
   * only answers once [thumbnailKey] has run on a worker thread and returns null otherwise.
   */
  fun peekThumbnailFromMemory(
    video: Video,
    widthPx: Int,
    heightPx: Int,
  ): Bitmap? {
    val key = resolvedThumbnailKeys.get(peekIdentity(video, widthPx, heightPx)) ?: return null
    return synchronized(memoryCache) {
      memoryCache.get(key)
    }
  }

  private fun peekIdentity(
    video: Video,
    widthPx: Int,
    heightPx: Int,
    generator: ThumbnailGenerator = browserPreferences.thumbnailGenerator.get(),
  ): String =
    "${video.path}|${video.uri}|${video.size}|${video.dateModified}|${video.duration}" +
      "|$widthPx|$heightPx|${thumbnailModeKey()}|${thumbnailQualityKey()}" +
      thumbnailGeneratorCacheKey(video, generator)

  // Keep extraction-quality changes from reusing smaller legacy images that were
  // cached without their requested dimensions in the key.
  fun diskCacheKey(
    video: Video,
    generator: ThumbnailGenerator = browserPreferences.thumbnailGenerator.get(),
    artworkTier: Int = 0,
  ): String =
    "${if (artworkTier > 0) "audio-art-v3|$artworkTier" else "video-thumb-v2"}|${diskVideoBaseKey(video)}|" +
      "${thumbnailModeKey()}|${thumbnailQualityKey()}" +
      thumbnailGeneratorCacheKey(video, generator)

  private fun isAudioArtwork(video: Video): Boolean =
    video.isAudio || video.mimeType.startsWith("audio/", ignoreCase = true) ||
      app.gyrolet.mpvrx.utils.storage.FileTypeUtils.isAudioFile(File(video.path.ifBlank { video.uri.path.orEmpty() }))

  /** Audio art is cached per display tier, so a list-row cover is never upscaled for a grid or player. */
  private fun audioArtworkTier(
    video: Video,
    widthPx: Int,
    heightPx: Int,
  ): Int {
    if (isNetworkUrl(video.path) || !isAudioArtwork(video)) return 0
    val requested = maxOf(widthPx, heightPx)
    val maxSize = thumbnailMaxSize()
    return when {
      requested <= AUDIO_ARTWORK_SMALL_TIER_PX -> AUDIO_ARTWORK_SMALL_TIER_PX
      requested <= MAX_THUMBNAIL_SIZE -> MAX_THUMBNAIL_SIZE
      else -> maxSize
    }.coerceAtMost(maxSize)
  }

  private fun thumbnailGeneratorCacheKey(video: Video, generator: ThumbnailGenerator): String =
    if (isNetworkUrl(video.path)) {
      ""
    } else {
      // Auto may cache native fallback artwork; keep it separate from strict MediaStore results.
      when (generator) {
        ThumbnailGenerator.Auto -> "|generator:Auto_v1"
        ThumbnailGenerator.Native -> ""
        ThumbnailGenerator.MediaStore -> "|generator:MediaStore_v2"
      }
    }

  private fun canonicalLocalPath(video: Video): String {
    if (app.gyrolet.mpvrx.BuildConfig.SCOPED_STORAGE_ONLY && video.uri.scheme == "content") {
      return video.uri.toString()
    }
    val raw = video.path.ifBlank { video.uri.toString() }
    if (isNetworkUrl(raw)) return raw
    if (ZipArchiveMedia.isPlaybackUri(raw)) return raw

    val decoded = runCatching { Uri.decode(raw) }.getOrNull() ?: raw

    if (decoded.startsWith("file://", ignoreCase = true)) {
      val parsed = runCatching { Uri.parse(decoded).path }.getOrNull()
      if (!parsed.isNullOrBlank()) return parsed
      return decoded.removePrefix("file://")
    }

    if (decoded.startsWith("content://", ignoreCase = true) || video.uri.scheme.equals("content", ignoreCase = true)) {
      val targetUri =
        if (decoded.startsWith("content://", ignoreCase = true)) {
          runCatching { Uri.parse(decoded) }.getOrNull() ?: video.uri
        } else {
          video.uri
        }
      val resolved = runCatching { targetUri.resolveLocalPath(context) }.getOrNull()
      if (!resolved.isNullOrBlank()) return resolved
    }

    if (video.uri.scheme.equals("file", ignoreCase = true)) {
      val p = video.uri.path
      if (!p.isNullOrBlank()) return p
    }

    return decoded
  }

  private fun resolveLocalMetadata(video: Video, source: String): ResolvedMetadata {
    if (video.size > 0L && video.dateModified > 0L && video.duration > 0L) {
      return ResolvedMetadata(video.size, video.dateModified, video.duration)
    }

    val cacheKey = "$source|${video.size}|${video.dateModified}|${video.duration}"
    localMetadataCache.get(cacheKey)?.takeIf { it.isFresh() }?.let { return it.value }

    var size = video.size
    var dateModified = video.dateModified
    var duration = video.duration

    val file = if (!source.contains("://")) File(source) else null
    if (file != null && file.exists()) {
      if (size <= 0L) size = file.length()
      if (dateModified <= 0L) dateModified = file.lastModified() / 1000L
    }

    // Query MediaStore which is indexed by Android
    runCatching {
      val projection =
        arrayOf(
          MediaStore.Video.Media.DURATION,
          MediaStore.Video.Media.SIZE,
          MediaStore.Video.Media.DATE_MODIFIED,
        )
      val cursor =
        when {
          video.uri.scheme == "content" &&
            video.uri.authority == MediaStore.AUTHORITY -> {
            context.contentResolver.query(video.uri, projection, null, null, null)
          }
          file != null -> {
            context.contentResolver.query(
              MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
              projection,
              "${MediaStore.Video.Media.DATA} = ?",
              arrayOf(source),
              null,
            )
          }
          else -> null
        }
      cursor?.use { c ->
        if (c.moveToFirst()) {
          val durCol = c.getColumnIndex(MediaStore.Video.Media.DURATION)
          val sizeCol = c.getColumnIndex(MediaStore.Video.Media.SIZE)
          val dateCol = c.getColumnIndex(MediaStore.Video.Media.DATE_MODIFIED)
          if (durCol >= 0 && duration <= 0L) duration = c.getLong(durCol)
          if (sizeCol >= 0 && size <= 0L) size = c.getLong(sizeCol)
          if (dateCol >= 0 && dateModified <= 0L) dateModified = c.getLong(dateCol)
        }
      }
    }

    val resolved = ResolvedMetadata(size, dateModified, duration)
    localMetadataCache.put(cacheKey, CachedIdentity(resolved))
    return resolved
  }

  private fun extractDurationFallback(video: Video): Long =
    runCatching {
      val retriever = MediaMetadataRetriever()
      try {
        setLocalDataSource(retriever, video)
        retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
      } finally {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) retriever.close() else retriever.release()
      }
    }.getOrDefault(0L)

  private fun videoBaseKey(video: Video): String {
    if (isNetworkUrl(video.path)) {
      val base = video.path.ifBlank { video.uri.toString() }
      return "$base|network"
    }

    val source = canonicalLocalPath(video)
    val meta = resolveLocalMetadata(video, source)
    return "$source|${meta.size}|${meta.dateModified}|${meta.duration}"
  }

  private fun memoryVideoBaseKey(video: Video): String {
    val baseKey = videoBaseKey(video)
    return diskVideoBaseKeyCache.get(baseKey)?.value ?: baseKey
  }

  /** Sidecar artwork probing is disk I/O, so keep it out of keys evaluated during composition. */
  private fun diskVideoBaseKey(video: Video): String {
    val baseKey = videoBaseKey(video)
    if (isNetworkUrl(video.path)) return baseKey
    diskVideoBaseKeyCache.get(baseKey)?.takeIf { it.isFresh() }?.let { return it.value }

    val canonicalPath = canonicalLocalPath(video)
    val artworkSignature =
      EmbeddedArtworkCandidates
        .forVideoPath(canonicalPath)
        .asSequence()
        .map(::File)
        .firstOrNull { it.isFile && it.canRead() }
        ?.let { artwork -> "|art:${artwork.name}:${artwork.length()}:${artwork.lastModified()}" }
        .orEmpty()
    val resolvedKey = "$baseKey$artworkSignature"
    diskVideoBaseKeyCache.put(baseKey, CachedIdentity(resolvedKey))
    return resolvedKey
  }

  private suspend fun generateLocalThumbnail(
    video: Video,
    widthPx: Int,
    heightPx: Int,
    generator: ThumbnailGenerator,
    artworkTier: Int = 0,
  ): Bitmap? {
    if (ZipArchiveMedia.isPlaybackUri(video.uri.toString())) return null
    val mode = browserPreferences.thumbnailMode.get()
    // Entries saved without media metadata (e.g. songs added to a playlist) arrive flagged as video.
    val canonicalPath = canonicalLocalPath(video)
    val isAudio =
      artworkTier > 0 || video.isAudio || video.mimeType.startsWith("audio/", ignoreCase = true) ||
        app.gyrolet.mpvrx.utils.storage.FileTypeUtils.isAudioFile(File(canonicalPath))
    val dimension =
      if (artworkTier > 0) artworkTier else maxOf(widthPx, heightPx, MAX_THUMBNAIL_SIZE).coerceAtMost(thumbnailMaxSize())
    fun fitRequest(bitmap: Bitmap): Bitmap =
      if (artworkTier > 0) bitmap.scaleToThumbnailMax(artworkTier) else scaleBitmap(bitmap, widthPx, heightPx)

    if (generator != ThumbnailGenerator.Native) {
      // Auto asks MediaStore first for every local source, including hidden/.nomedia folders
      // and granted document URIs. An unindexed file follows the same native fallback below.
      MediaStoreThumbnailLoader.load(context, video, canonicalPath, dimension, isAudio)?.let {
        return fitRequest(it)
      }
      // Explicit MediaStore mode stays Android-only; only Auto falls back to native extraction.
      if (generator == ThumbnailGenerator.MediaStore) return null
      currentCoroutineContext().ensureActive()
    }

    if (isAudio || mode == ThumbnailMode.Smart || mode == ThumbnailMode.EmbeddedThumbnail) {
      generateEmbeddedArtwork(video)?.let { return fitRequest(it) }
      if (isAudio) {
        return null
      }
    }

    generateWithFastThumbnails(video, mode, dimension)?.let {
      return scaleBitmap(it, widthPx, heightPx)
    }

    return extractLocalVideoFrame(video, widthPx, heightPx)
  }

  private fun generateEmbeddedArtwork(video: Video): Bitmap? {
    val canonicalPath = canonicalLocalPath(video)
    // Some Android retrievers reject Matroska attachments or SAF providers. Their failure must
    // not prevent the independent container/sidecar artwork paths from being tried.
    val retrieverArtwork =
      runCatching {
        val retriever = MediaMetadataRetriever()
        try {
          setLocalDataSource(retriever, video)
          EmbeddedArtworkResolver.decodeRetrieverArtwork(retriever)
        } finally {
          runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) retriever.close() else retriever.release()
          }
        }
      }.getOrNull()
    return (
      retrieverArtwork
        ?: EmbeddedArtworkResolver.decodeContainerOrSidecar(
          videoPath = canonicalPath,
          context = context,
          videoUri = video.uri,
          displayName = video.displayName,
        )
      )?.scaleToThumbnailMax(thumbnailMaxSize())
  }

  private suspend fun generateWithFastThumbnails(
    video: Video,
    mode: ThumbnailMode,
    dimension: Int,
  ): Bitmap? {
    val canonicalPath = canonicalLocalPath(video)
    if (video.isAudio || canonicalPath.isBlank()) return null
    val targetVideo = if (video.path != canonicalPath) video.copy(path = canonicalPath) else video

    val resolvedDuration =
      if (targetVideo.duration > 0L) {
        targetVideo.duration
      } else {
        val metaDur = resolveLocalMetadata(targetVideo, canonicalPath).duration
        if (metaDur > 0L) metaDur else extractDurationFallback(targetVideo)
      }
    val durationSeconds = resolvedDuration.coerceAtLeast(0L) / 1000.0
    val requestedPosition =
      when (mode) {
        ThumbnailMode.FirstFrame, ThumbnailMode.EmbeddedThumbnail -> 0.0
        ThumbnailMode.FrameAtPosition ->
          durationSeconds * (browserPreferences.thumbnailFramePosition.get() / 100.0).coerceIn(0.0, 1.0)
        ThumbnailMode.Smart -> durationSeconds * 0.33
      }
    val lastSafePosition = (durationSeconds - 0.1).coerceAtLeast(0.0)
    val positions =
      listOf(requestedPosition).map { position ->
        if (durationSeconds > 0.0) position.coerceIn(0.0, lastSafePosition) else position.coerceAtLeast(0.0)
      }.distinct()

    var lastSolidBitmap: Bitmap? = null
    for (position in positions) {
      val bitmap =
        try {
          FastThumbnails.generateAsync(
            targetVideo.path,
            position,
            dimension,
            useHwDec = false,
          )
        } catch (cancellation: CancellationException) {
          lastSolidBitmap?.takeUnless { it.isRecycled }?.recycle()
          throw cancellation
        } catch (_: Exception) {
          continue
        } ?: continue

      if (mode == ThumbnailMode.Smart && isMostlySolidThumbnail(bitmap)) {
        lastSolidBitmap?.takeUnless { it.isRecycled }?.recycle()
        lastSolidBitmap = bitmap
        continue
      }

      lastSolidBitmap?.takeUnless { it.isRecycled }?.recycle()
      return rotateNativeThumbnail(video, bitmap)
    }

    return lastSolidBitmap?.let { rotateNativeThumbnail(video, it) }
  }

  private suspend fun rotateNativeThumbnail(
    video: Video,
    bitmap: Bitmap,
  ): Bitmap {
    val rotation =
      try {
        app.gyrolet.mpvrx.utils.media.MediaInfoOps
          .getRotation(context, video.uri, video.displayName)
      } catch (cancellation: CancellationException) {
        bitmap.takeUnless { it.isRecycled }?.recycle()
        throw cancellation
      } catch (_: Exception) {
        0
      }
    if (rotation == 0) return bitmap

    val rotated =
      Bitmap.createBitmap(
        bitmap,
        0,
        0,
        bitmap.width,
        bitmap.height,
        Matrix().apply { postRotate(rotation.toFloat()) },
        true,
      )
    if (rotated !== bitmap && !bitmap.isRecycled) bitmap.recycle()
    return rotated
  }

  private fun extractLocalVideoFrame(
    video: Video,
    widthPx: Int,
    heightPx: Int,
  ): Bitmap? =
    runCatching {
      val retriever = MediaMetadataRetriever()
      try {
        setLocalDataSource(retriever, video)
        extractFrameWithStrategy(
          retriever = retriever,
          strategy =
            browserPreferences.thumbnailMode.get().toThumbnailStrategy(
              browserPreferences.thumbnailFramePosition.get(),
            ),
          targetWidth = widthPx.takeIf { it > 0 },
          targetHeight = heightPx.takeIf { it > 0 },
          videoPath = canonicalLocalPath(video),
        )
      } finally {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) retriever.close() else retriever.release()
      }
    }.getOrNull()

  private fun setLocalDataSource(
    retriever: MediaMetadataRetriever,
    video: Video,
  ) {
    val canonicalPath = canonicalLocalPath(video)
    when {
      app.gyrolet.mpvrx.BuildConfig.SCOPED_STORAGE_ONLY && video.uri.scheme == "content" ->
        retriever.setDataSource(context, video.uri)
      canonicalPath.isNotBlank() && !canonicalPath.contains("://") && File(canonicalPath).exists() ->
        retriever.setDataSource(canonicalPath)
      video.path.isNotBlank() && !video.path.contains("://") -> retriever.setDataSource(video.path)
      else -> retriever.setDataSource(context, video.uri)
    }
  }

  private fun readBitmapFromDisk(
    key: String,
    network: Boolean,
    widthPx: Int = 0,
    heightPx: Int = 0,
    fullColor: Boolean = false,
  ): Bitmap? =
    diskCacheLock.read {
      val file = File(if (network) networkDiskDir else localDiskDir, keyToFileName(key))
      if (!file.isFile) return@read null

      runCatching {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        BitmapFactory.decodeFile(
          file.absolutePath,
          BitmapFactory.Options().apply {
            inSampleSize = calculateThumbnailSampleSize(bounds.outWidth, bounds.outHeight, thumbnailMaxSize(), widthPx, heightPx)
            // RGB_565 bands the gradients common in cover art; video frames tolerate it.
            inPreferredConfig = if (fullColor) Bitmap.Config.ARGB_8888 else Bitmap.Config.RGB_565
          },
        )
      }.getOrNull()
    }

  private fun writeBitmapToDisk(
    key: String,
    bitmap: Bitmap,
    network: Boolean,
    revision: Long,
  ) {
    val file = File(if (network) networkDiskDir else localDiskDir, keyToFileName(key))
    val encoded =
      runCatching {
        ByteArrayOutputStream().use { buffer ->
          if (bitmap.compress(Bitmap.CompressFormat.JPEG, THUMBNAIL_JPEG_QUALITY, buffer)) {
            buffer.toByteArray()
          } else {
            null
          }
        }
      }.getOrNull() ?: return

    diskCacheLock.write {
      if (revision != cacheRevision.value) return@write
      runCatching {
        FileOutputStream(file).use { output ->
          output.write(encoded)
        }
      }
    }
  }

  private fun keyToFileName(key: String): String =
    MessageDigest
      .getInstance("SHA-256")
      .digest(key.toByteArray())
      .toLowerHex() + ".jpg"

  private fun scaleBitmap(
    bitmap: Bitmap,
    widthPx: Int,
    heightPx: Int,
  ): Bitmap {
    if (widthPx <= 0 || heightPx <= 0 || bitmap.isRecycled) {
      return bitmap
    }

    val scale = max(widthPx / bitmap.width.toFloat(), heightPx / bitmap.height.toFloat())
    if (scale >= 1f && bitmap.width <= widthPx * 2 && bitmap.height <= heightPx * 2) {
      return bitmap
    }

    val scaledWidth = max(1, (bitmap.width * scale).roundToInt())
    val scaledHeight = max(1, (bitmap.height * scale).roundToInt())
    val scaled =
      try {
        Bitmap.createScaledBitmap(bitmap, scaledWidth, scaledHeight, true)
      } catch (_: IllegalArgumentException) {
        // Bitmap was recycled between the check and the scale call
        return bitmap
      }
    if (scaled != bitmap && !bitmap.isRecycled) {
      bitmap.recycle()
    }
    return scaled
  }

  private fun isNetworkUrl(path: String): Boolean =
    path.startsWith("http://", ignoreCase = true) ||
      path.startsWith("https://", ignoreCase = true) ||
      path.startsWith("rtmp://", ignoreCase = true) ||
      path.startsWith("rtsp://", ignoreCase = true) ||
      path.startsWith("ftp://", ignoreCase = true) ||
      path.startsWith("sftp://", ignoreCase = true) ||
      path.startsWith("smb://", ignoreCase = true)

  private fun isHttpUrl(path: String): Boolean =
    path.startsWith("http://", ignoreCase = true) ||
      path.startsWith("https://", ignoreCase = true)

  private suspend fun getOrCreateNetworkVideoThumbnail(
    video: Video,
    widthPx: Int,
    heightPx: Int,
  ): Bitmap? {
    val jellyfinImageUrls = extractJellyfinImageUrls(video.path, maxOf(widthPx, heightPx, 400))
    for (url in jellyfinImageUrls) {
      val jellyfinBitmap = fetchHttpImage(url)
      if (jellyfinBitmap != null) {
        return scaleBitmap(jellyfinBitmap, widthPx, heightPx)
      }
    }

    if (!appearancePreferences.showNetworkThumbnails.get()) {
      return null
    }

    val strategy =
      browserPreferences.thumbnailMode.get().toThumbnailStrategy(
        browserPreferences.thumbnailFramePosition.get(),
      )

    val rotated =
      extractNetworkVideoFrame(
        url = video.path,
        strategy = strategy,
        targetWidth = widthPx.takeIf { it > 0 },
        targetHeight = heightPx.takeIf { it > 0 },
      ) ?: generateFastNetworkThumbnail(video.path, widthPx, heightPx) ?: return null

    return scaleBitmap(rotated, widthPx, heightPx)
  }

  private fun isNetworkThumbnailAllowed(path: String): Boolean =
    extractJellyfinImageUrls(path).isNotEmpty() || appearancePreferences.showNetworkThumbnails.get()

  private fun extractJellyfinImageUrls(url: String, maxWidth: Int = 400): List<String> =
    runCatching {
      val uri = Uri.parse(url)
      val pathSegments = uri.pathSegments
      val videosIndex = pathSegments.indexOf("Videos")
      val itemsIndex = pathSegments.indexOf("Items")
      val audioIndex = pathSegments.indexOf("Audio")
      val targetIndex =
        when {
          videosIndex != -1 -> videosIndex
          itemsIndex != -1 -> itemsIndex
          audioIndex != -1 -> audioIndex
          else -> -1
        }
      if (targetIndex == -1 || targetIndex + 1 >= pathSegments.size) return emptyList()
      val itemId = pathSegments[targetIndex + 1]
      val apiKey = uri.getQueryParameter("api_key") ?: uri.getQueryParameter("ApiKey")
      val scheme = uri.scheme ?: "http"
      val authority = uri.encodedAuthority ?: return emptyList()
      val subPathSegments = pathSegments.subList(0, targetIndex)
      val base =
        if (subPathSegments.isEmpty()) {
          "$scheme://$authority"
        } else {
          "$scheme://$authority/" + subPathSegments.joinToString("/")
        }
      val tokenParam = if (!apiKey.isNullOrBlank()) "&api_key=$apiKey" else ""
      listOf(
        "$base/Items/$itemId/Images/Primary?maxWidth=$maxWidth&quality=80$tokenParam",
        "$base/Items/$itemId/Images/Primary?fallback=true&maxWidth=$maxWidth&quality=80$tokenParam",
        "$base/Items/$itemId/Images/Thumb?maxWidth=$maxWidth&quality=80$tokenParam",
        "$base/Items/$itemId/Images/Backdrop/0?maxWidth=$maxWidth&quality=80$tokenParam",
      )
    }.getOrDefault(emptyList())

  private suspend fun fetchHttpImage(url: String): Bitmap? =
    withContext(Dispatchers.IO) {
      runCatching {
        val connection =
          (java.net.URL(url).openConnection() as java.net.HttpURLConnection).apply {
            connectTimeout = 4000
            readTimeout = 6000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "mpvRx/1.0")
          }
        if (connection.responseCode in 200..299) {
          connection.inputStream.use { stream ->
            BitmapFactory.decodeStream(stream)
          }
        } else {
          null
        }
      }.getOrNull()
    }

  private fun extractNetworkVideoFrame(
    url: String,
    strategy: ThumbnailStrategy,
    targetWidth: Int?,
    targetHeight: Int?,
  ): Bitmap? =
    runCatching {
      val retriever = MediaMetadataRetriever()
      try {
        retriever.setDataSource(url, networkVideoHeaders())

        extractFrameWithStrategy(retriever, strategy, targetWidth, targetHeight)
      } finally {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) retriever.close() else retriever.release()
      }
    }.getOrNull()

  private fun extractFrameWithStrategy(
    retriever: MediaMetadataRetriever,
    strategy: ThumbnailStrategy,
    targetWidth: Int?,
    targetHeight: Int?,
    videoPath: String? = null,
  ): Bitmap? {
    val embeddedPicture =
      if (strategy.prefersEmbeddedPicture()) {
        EmbeddedArtworkResolver.decodeEmbeddedArtwork(videoPath, retriever)
      } else {
        null
      }
    val timeUs =
      when (strategy) {
        ThumbnailStrategy.FirstFrame -> 0L
        is ThumbnailStrategy.FrameAtPercentage -> frameTimeMicros(retriever, strategy.percentage)
        is ThumbnailStrategy.Hybrid, is ThumbnailStrategy.EmbeddedOrHybrid -> 0L
        ThumbnailStrategy.EmbeddedOrFirstFrame -> 0L
      }

    var shouldRotate = true
    val raw =
      when (strategy) {
        ThumbnailStrategy.EmbeddedOrFirstFrame ->
          embeddedPicture?.also { shouldRotate = false }
            ?: getFrameAt(retriever, timeUs, targetWidth, targetHeight)
        ThumbnailStrategy.FirstFrame -> getFrameAt(retriever, 0L, targetWidth, targetHeight)
        is ThumbnailStrategy.FrameAtPercentage -> getFrameAt(retriever, timeUs, targetWidth, targetHeight)
        is ThumbnailStrategy.Hybrid -> decodeHybridFrame(retriever, strategy.percentage, targetWidth, targetHeight)
        is ThumbnailStrategy.EmbeddedOrHybrid ->
          embeddedPicture?.also { shouldRotate = false }
            ?: getFrameAt(retriever, frameTimeMicros(retriever, strategy.percentage), targetWidth, targetHeight)
      } ?: return null

    return if (shouldRotate) rotateBitmapIfNeeded(retriever, raw) else raw
  }

  private fun decodeHybridFrame(
    retriever: MediaMetadataRetriever,
    percentage: Float,
    targetWidth: Int?,
    targetHeight: Int?,
  ): Bitmap? {
    val first = getFrameAt(retriever, 0L, targetWidth, targetHeight) ?: return null
    if (!isMostlySolidThumbnail(first)) return first
    first.recycle()
    return getFrameAt(
      retriever,
      frameTimeMicros(retriever, percentage),
      targetWidth,
      targetHeight,
    )
  }

  private fun getFrameAt(
    retriever: MediaMetadataRetriever,
    timeUs: Long,
    targetWidth: Int?,
    targetHeight: Int?,
  ): Bitmap? {
    val w = targetWidth ?: return retriever.getFrameAtTime(timeUs)
    val h = targetHeight ?: return retriever.getFrameAtTime(timeUs)
    if (w <= 0 || h <= 0) {
      return retriever.getFrameAtTime(timeUs)
    }
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
      runCatching {
        retriever.getScaledFrameAtTime(
          timeUs,
          MediaMetadataRetriever.OPTION_CLOSEST_SYNC,
          w,
          h,
        )
      }.getOrNull()
        ?: retriever.getFrameAtTime(timeUs)
    } else {
      retriever.getFrameAtTime(timeUs)
    }
  }

  private fun frameTimeMicros(
    retriever: MediaMetadataRetriever,
    percentage: Float,
  ): Long {
    val durationMs =
      retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
    return (durationMs * percentage.coerceIn(0f, 1f) * 1000).toLong()
  }

  private fun rotateBitmapIfNeeded(
    retriever: MediaMetadataRetriever,
    bitmap: Bitmap,
  ): Bitmap {
    val rotation =
      retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull()
        ?: return bitmap
    if (rotation == 0) {
      return bitmap
    }

    val matrix = Matrix().apply { postRotate(rotation.toFloat()) }
    val rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    if (rotated != bitmap) {
      bitmap.recycle()
    }
    return rotated
  }

  private fun networkVideoHeaders(): Map<String, String> =
    mapOf(
      // Some servers refuse requests without a UA. MediaMetadataRetriever handles the rest.
      "User-Agent" to "Mozilla/5.0 (Android) mpvRx",
      "Accept" to "*/*",
    )

  /**
   * Retrieve a thumbnail for a raw network file path (for use from [NetworkVideoCard]).
   * For HTTP/HTTPS URLs, uses [MediaMetadataRetriever]'s built-in HTTP streaming.
   * For other protocols (SMB, FTP, WebDAV), uses [NetworkStreamingProxy] to create
   * a local HTTP stream and then extracts the frame.
   * Respects the [showNetworkThumbnails] preference gate.
   */
  suspend fun getThumbnailForNetworkPath(
    path: String,
    widthPx: Int,
    heightPx: Int,
    connection: NetworkConnection? = null,
    fileSize: Long = -1L,
    mimeType: String? = null,
  ): Bitmap? =
    withContext(Dispatchers.IO) {
      val revision = diskCacheLock.read { cacheRevision.value }
      if (!appearancePreferences.showNetworkThumbnails.get()) return@withContext null

      val identity = networkThumbnailIdentity(path, connection)
      val memKey = networkThumbnailMemoryKey(identity, widthPx, heightPx)
      synchronized(memoryCache) { memoryCache.get(memKey) }?.let { return@withContext it }
      ongoingOperations[memKey]?.let { return@withContext it.await() }

      val candidate =
        async(start = CoroutineStart.LAZY) {
          if (!isHttpUrl(path)) {
            return@async getNonHttpNetworkThumbnail(
              path = path,
              connection = connection,
              widthPx = widthPx,
              heightPx = heightPx,
              identity = identity,
              fileSize = fileSize,
              mimeType = mimeType,
              revision = revision,
            )
          }

          if (hasRecentNetworkThumbnailFailure(identity)) {
            android.util.Log.d("ThumbnailRepository", "Skipping network thumbnail (previously failed): $path")
            return@async null
          }

          val diskKey = networkThumbnailDiskKey(identity)
          readBitmapFromDisk(diskKey, network = true)?.let { bitmap ->
            val scaled = scaleBitmap(bitmap, widthPx, heightPx)
            diskCacheLock.read {
              if (revision != cacheRevision.value) return@async null
              synchronized(memoryCache) { memoryCache.put(memKey, scaled) }
            }
            return@async scaled
          }

          val strategy =
            browserPreferences.thumbnailMode.get().toThumbnailStrategy(
              browserPreferences.thumbnailFramePosition.get(),
            )
          val bitmap =
            networkGenerationSemaphore.withPermit {
              (
                extractNetworkVideoFrame(
                  url = path,
                  strategy = strategy,
                  targetWidth = widthPx.takeIf { it > 0 },
                  targetHeight = heightPx.takeIf { it > 0 },
                ) ?: generateFastNetworkThumbnail(path, widthPx, heightPx)
              )?.let { scaleBitmap(it, widthPx, heightPx) }
            }

          if (bitmap == null) {
            android.util.Log.w("ThumbnailRepository", "All strategies failed for network stream $path")
            networkThumbnailFailedAt.put(identity, SystemClock.elapsedRealtime())
            return@async null
          }

          currentCoroutineContext().ensureActive()
          networkThumbnailFailedAt.remove(identity)
          writeBitmapToDisk(diskKey, bitmap, network = true, revision = revision)
          diskCacheLock.read {
            if (revision != cacheRevision.value) return@async null
            synchronized(memoryCache) { memoryCache.put(memKey, bitmap) }
          }
          _thumbnailReadyKeys.tryEmit(memKey)
          bitmap
        }

      val operation =
        ongoingOperations.putIfAbsent(memKey, candidate)?.also {
          candidate.cancel()
        } ?: candidate.also { owned ->
          owned.invokeOnCompletion { ongoingOperations.remove(memKey, owned) }
          owned.start()
        }
      operation.await()
    }

  suspend fun getThumbnailForNetworkSource(
    connectionId: Long,
    path: String,
    widthPx: Int,
    heightPx: Int,
  ): Bitmap? {
    // Tombstones included: the cache key needs only this connection's identity, and an entry whose
    // share was deleted must keep showing the frame that is already on disk.
    val connection = networkRepository.getConnectionIncludingDeleted(connectionId) ?: return null
    return getThumbnailForNetworkPath(
      path = path,
      widthPx = widthPx,
      heightPx = heightPx,
      connection = connection,
    )
  }

  private suspend fun getNonHttpNetworkThumbnail(
    path: String,
    connection: NetworkConnection?,
    widthPx: Int,
    heightPx: Int,
    identity: String,
    fileSize: Long,
    mimeType: String?,
    revision: Long,
  ): Bitmap? {
    if (hasRecentNetworkThumbnailFailure(identity)) {
      android.util.Log.d("ThumbnailRepository", "Skipping network thumbnail (previously failed): $path")
      return null
    }

    val memKey = networkThumbnailMemoryKey(identity, widthPx, heightPx)
    val diskKey = networkThumbnailDiskKey(identity)

    // Memory cache hit
    synchronized(memoryCache) { memoryCache.get(memKey) }?.let { return it }

    // Disk cache hit
    readBitmapFromDisk(diskKey, network = true)?.let { bitmap ->
      val scaled = scaleBitmap(bitmap, widthPx, heightPx)
      diskCacheLock.read {
        if (revision != cacheRevision.value) return null
        synchronized(memoryCache) { memoryCache.put(memKey, scaled) }
      }
      return scaled
    }

    val strategy =
      browserPreferences.thumbnailMode.get().toThumbnailStrategy(
        browserPreferences.thumbnailFramePosition.get(),
      )

    val bitmap =
      networkGenerationSemaphore.withPermit {
        (
          if (connection != null) {
            extractNetworkVideoFrameViaProxy(
              path = path,
              connection = connection,
              strategy = strategy,
              targetWidth = widthPx,
              targetHeight = heightPx,
              fileSize = fileSize,
              mimeType = mimeType,
            )
          } else {
            generateFastNetworkThumbnail(path, widthPx, heightPx)
          }
        )?.let { scaleBitmap(it, widthPx, heightPx) }
      }

    if (bitmap == null) {
      android.util.Log.w("ThumbnailRepository", "All strategies failed for network path $path")
      networkThumbnailFailedAt.put(identity, SystemClock.elapsedRealtime())
      return null
    }

    networkThumbnailFailedAt.remove(identity)

    currentCoroutineContext().ensureActive()
    writeBitmapToDisk(diskKey, bitmap, network = true, revision = revision)
    diskCacheLock.read {
      if (revision != cacheRevision.value) return null
      synchronized(memoryCache) { memoryCache.put(memKey, bitmap) }
    }
    _thumbnailReadyKeys.tryEmit(memKey)
    return bitmap
  }

  private suspend fun extractNetworkVideoFrameViaProxy(
    path: String,
    connection: NetworkConnection,
    strategy: ThumbnailStrategy,
    targetWidth: Int,
    targetHeight: Int,
    fileSize: Long,
    mimeType: String?,
  ): Bitmap? {
    val proxy = NetworkStreamingProxy.getInstance()
    val streamId = "thumb_${path.hashCode()}_${System.nanoTime()}"

    return try {
      val localUrl =
        proxy.registerStream(
          streamId = streamId,
          connection = connection,
          filePath = path,
          fileSize = fileSize.coerceAtLeast(-1L),
          mimeType = mimeType ?: NetworkMimeTypes.forFileName(path) ?: "application/octet-stream",
        )

      extractNetworkVideoFrame(
        url = localUrl,
        strategy = strategy,
        targetWidth = targetWidth.takeIf { it > 0 },
        targetHeight = targetHeight.takeIf { it > 0 },
      ) ?: generateFastNetworkThumbnail(localUrl, targetWidth, targetHeight)
    } catch (cancellation: CancellationException) {
      throw cancellation
    } catch (_: Exception) {
      null
    } finally {
      proxy.unregisterStream(streamId)
    }
  }

  /** The memory-cache key used by [getThumbnailForNetworkPath]. */
  fun thumbnailKeyForNetworkPath(
    path: String,
    widthPx: Int,
    heightPx: Int,
    connection: NetworkConnection? = null,
  ): String =
    networkThumbnailMemoryKey(
      networkThumbnailIdentity(path, connection),
      widthPx,
      heightPx,
    )

  /**
   * Cache identity for a network thumbnail: the share endpoint plus the path, nothing else.
   *
   * Size and modification time are deliberately excluded. A playlist entry knows neither, so
   * folding them in gave one file two different cache entries — one per screen showing it — and
   * made the second screen download and extract the frame again. The trade-off is that replacing
   * a file in place keeps serving the previous thumbnail until the cache is cleared.
   */
  private fun networkThumbnailIdentity(
    path: String,
    connection: NetworkConnection?,
  ): String {
    val endpoint =
      connection?.let {
        "${it.id}|${it.protocol.name}|${it.host.lowercase()}|${it.port}|${it.path}|${it.useHttps}"
      } ?: "direct"
    return "$endpoint|$path"
  }

  private fun networkThumbnailMemoryKey(
    identity: String,
    widthPx: Int,
    heightPx: Int,
  ): String = "$identity|network|$widthPx|$heightPx|${thumbnailModeKey()}|${thumbnailQualityKey()}"

  private fun networkThumbnailDiskKey(identity: String): String =
    "video-thumb-v3|$identity|network|${thumbnailModeKey()}|${thumbnailQualityKey()}"

  private fun hasRecentNetworkThumbnailFailure(identity: String): Boolean {
    return synchronized(networkThumbnailFailedAt) {
      val failedAt = networkThumbnailFailedAt.get(identity) ?: return@synchronized false
      if (SystemClock.elapsedRealtime() - failedAt < NETWORK_THUMBNAIL_FAILURE_RETRY_MS) return@synchronized true
      networkThumbnailFailedAt.remove(identity)
      false
    }
  }

  private fun folderSignature(
    videos: List<Video>,
    widthPx: Int,
    heightPx: Int,
  ): String {
    val md = MessageDigest.getInstance("MD5")
    md.update("$widthPx|$heightPx|${thumbnailModeKey()}|${thumbnailQualityKey()}|${browserPreferences.thumbnailGenerator.get().name}|".toByteArray())
    for (video in videos) {
      md.update(video.path.toByteArray())
      md.update("|".toByteArray())
      md.update(video.size.toString().toByteArray())
      md.update("|".toByteArray())
      md.update(video.dateModified.toString().toByteArray())
      md.update(";".toByteArray())
    }
    return md.digest().toLowerHex()
  }

  private fun thumbnailModeKey(): String =
    browserPreferences.thumbnailMode.get().thumbnailModeCacheKey(browserPreferences.thumbnailFramePosition.get())

  private fun thumbnailQualityKey(): String = browserPreferences.thumbnailQuality.get().name

  private fun thumbnailMaxSize(): Int = browserPreferences.thumbnailQuality.get().maxSizePx

  private fun resolveLocalGenerationParallelism(): Int {
    val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
    return thumbnailParallelism(
      lowRam = app.gyrolet.mpvrx.utils.device.DevicePerformance.isLowEnd || activityManager?.isLowRamDevice == true,
      memoryClassMb = activityManager?.memoryClass ?: 0,
      processorCount = Runtime.getRuntime().availableProcessors().coerceAtLeast(1),
      sdkInt = Build.VERSION.SDK_INT,
    )
  }

  private suspend fun generateFastNetworkThumbnail(
    path: String,
    widthPx: Int,
    heightPx: Int,
  ): Bitmap? =
    try {
      FastThumbnails.generateAsync(
        path,
        10.0,
        maxOf(widthPx, heightPx, MAX_THUMBNAIL_SIZE).coerceAtMost(thumbnailMaxSize()),
        useHwDec = false,
      )
    } catch (cancellation: CancellationException) {
      throw cancellation
    } catch (_: Exception) {
      null
    }
}
