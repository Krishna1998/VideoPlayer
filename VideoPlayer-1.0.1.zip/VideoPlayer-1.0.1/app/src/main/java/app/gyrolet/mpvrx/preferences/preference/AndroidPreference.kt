/*
 * SPDX-License-Identifier: AGPL-3.0-or-later
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

package app.gyrolet.mpvrx.preferences.preference

import android.content.SharedPreferences
import android.content.SharedPreferences.Editor
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.core.content.edit
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.conflate
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onStart
import kotlinx.coroutines.flow.stateIn

sealed class AndroidPreference<T>(
  private val preferences: SharedPreferences,
  private val keyFlow: Flow<String?>,
  private val key: String,
  private val defaultValue: T,
) : Preference<T> {
  abstract fun read(
    preferences: SharedPreferences,
    key: String,
    defaultValue: T,
  ): T

  abstract fun write(
    key: String,
    value: T,
  ): Editor.() -> Unit

  override fun key(): String = key

  override fun get(): T =
    try {
      read(preferences, key, defaultValue)
    } catch (_: ClassCastException) {
      delete()
      defaultValue
    }

  override fun set(value: T) {
    preferences.edit(action = write(key, value))
  }

  override fun isSet(): Boolean = preferences.contains(key)

  override fun delete() {
    preferences.edit {
      remove(key)
    }
  }

  override fun defaultValue(): T = defaultValue

  override fun changes(): Flow<T> =
    keyFlow
      .filter { it == key || it == null }
      .onStart { emit("ignition") }
      .map { get() }
      .conflate()

  override fun stateIn(scope: CoroutineScope): StateFlow<T> =
    changes().stateIn(scope, SharingStarted.WhileSubscribed(stopTimeoutMillis = 5_000), get())

  private var sharedComposeState: MutableState<T>? = null

  // SharedPreferences holds listeners weakly; this field keeps the listener alive with the preference.
  private val composeStateListener =
    SharedPreferences.OnSharedPreferenceChangeListener { _, changedKey ->
      if (changedKey == null || changedKey == key) sharedComposeState?.value = get()
    }

  /**
   * One snapshot state shared by every composable observing this preference. Collecting [changes]
   * per call site started two coroutines and a channel for each one, and list rows observe several
   * preferences each. Called from composition; listener callbacks also arrive on the main thread.
   */
  internal fun composeState(): State<T> {
    sharedComposeState?.let { return it }
    preferences.registerOnSharedPreferenceChangeListener(composeStateListener)
    return mutableStateOf(get()).also { sharedComposeState = it }
  }

  class StringPrimitive(
    preferences: SharedPreferences,
    keyFlow: Flow<String?>,
    key: String,
    defaultValue: String,
  ) : AndroidPreference<String>(preferences, keyFlow, key, defaultValue) {
    override fun read(
      preferences: SharedPreferences,
      key: String,
      defaultValue: String,
    ): String = preferences.getString(key, defaultValue) ?: defaultValue

    override fun write(
      key: String,
      value: String,
    ): Editor.() -> Unit =
      {
        putString(key, value)
      }
  }

  class LongPrimitive(
    preferences: SharedPreferences,
    keyFlow: Flow<String?>,
    key: String,
    defaultValue: Long,
  ) : AndroidPreference<Long>(preferences, keyFlow, key, defaultValue) {
    override fun read(
      preferences: SharedPreferences,
      key: String,
      defaultValue: Long,
    ): Long = preferences.getLong(key, defaultValue)

    override fun write(
      key: String,
      value: Long,
    ): Editor.() -> Unit =
      {
        putLong(key, value)
      }
  }

  class IntPrimitive(
    preferences: SharedPreferences,
    keyFlow: Flow<String?>,
    key: String,
    defaultValue: Int,
  ) : AndroidPreference<Int>(preferences, keyFlow, key, defaultValue) {
    override fun read(
      preferences: SharedPreferences,
      key: String,
      defaultValue: Int,
    ): Int = preferences.getInt(key, defaultValue)

    override fun write(
      key: String,
      value: Int,
    ): Editor.() -> Unit =
      {
        putInt(key, value)
      }
  }

  class FloatPrimitive(
    preferences: SharedPreferences,
    keyFlow: Flow<String?>,
    key: String,
    defaultValue: Float,
  ) : AndroidPreference<Float>(preferences, keyFlow, key, defaultValue) {
    override fun read(
      preferences: SharedPreferences,
      key: String,
      defaultValue: Float,
    ): Float = preferences.getFloat(key, defaultValue)

    override fun write(
      key: String,
      value: Float,
    ): Editor.() -> Unit =
      {
        putFloat(key, value)
      }
  }

  class BooleanPrimitive(
    preferences: SharedPreferences,
    keyFlow: Flow<String?>,
    key: String,
    defaultValue: Boolean,
  ) : AndroidPreference<Boolean>(preferences, keyFlow, key, defaultValue) {
    override fun read(
      preferences: SharedPreferences,
      key: String,
      defaultValue: Boolean,
    ): Boolean = preferences.getBoolean(key, defaultValue)

    override fun write(
      key: String,
      value: Boolean,
    ): Editor.() -> Unit =
      {
        putBoolean(key, value)
      }
  }

  class StringSetPrimitive(
    preferences: SharedPreferences,
    keyFlow: Flow<String?>,
    key: String,
    defaultValue: Set<String>,
  ) : AndroidPreference<Set<String>>(preferences, keyFlow, key, defaultValue) {
    override fun read(
      preferences: SharedPreferences,
      key: String,
      defaultValue: Set<String>,
    ): Set<String> = preferences.getStringSet(key, defaultValue) ?: defaultValue

    override fun write(
      key: String,
      value: Set<String>,
    ): Editor.() -> Unit =
      {
        putStringSet(key, value)
      }
  }

  class Object<T>(
    preferences: SharedPreferences,
    keyFlow: Flow<String?>,
    key: String,
    defaultValue: T,
    val serializer: (T) -> String,
    val deserializer: (String) -> T,
  ) : AndroidPreference<T>(preferences, keyFlow, key, defaultValue) {
    override fun read(
      preferences: SharedPreferences,
      key: String,
      defaultValue: T,
    ): T =
      try {
        preferences.getString(key, null)?.let(deserializer) ?: defaultValue
      } catch (_: Exception) {
        defaultValue
      }

    override fun write(
      key: String,
      value: T,
    ): Editor.() -> Unit =
      {
        putString(key, serializer(value))
      }
  }
}
