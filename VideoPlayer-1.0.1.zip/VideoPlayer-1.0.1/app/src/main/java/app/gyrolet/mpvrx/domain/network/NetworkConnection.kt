/*
 * SPDX-License-Identifier: AGPL-3.0-or-later
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

package app.gyrolet.mpvrx.domain.network

import androidx.compose.runtime.Immutable
import androidx.room.Entity
import androidx.room.ColumnInfo
import androidx.room.PrimaryKey

/**
 * Represents a network connection configuration
 */
@Entity(tableName = "network_connections")
@Immutable
data class NetworkConnection(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val name: String,
  val protocol: NetworkProtocol,
  val host: String,
  val port: Int,
  val username: String = "",
  val password: String = "",
  val path: String = "/",
  val isAnonymous: Boolean = false,
  val lastConnected: Long = 0,
  val autoConnect: Boolean = false,
  val useHttps: Boolean = false, // For WebDAV: use HTTPS instead of HTTP
  /**
   * Deleted connections are kept as tombstones rather than removed. Playlist entries reference a
   * connection by this row's id, so re-creating the same settings can revive the row and keep that
   * id instead of orphaning every entry that pointed at it.
   */
  @ColumnInfo(defaultValue = "0")
  val isDeleted: Boolean = false,
) {
  override fun toString(): String =
    "NetworkConnection(id=$id, name=$name, protocol=$protocol, credentials=<redacted>)"
}

/**
 * Supported network protocols
 */
enum class NetworkProtocol(
  val displayName: String,
  val defaultPort: Int,
) {
  SMB("SMB", 445),
  FTP("FTP", 21),
  WEBDAV("WebDAV", 80),
  SFTP("SFTP", 22),
}

/**
 * Runtime status of a network connection
 */
@Immutable
data class ConnectionStatus(
  val connectionId: Long,
  val isConnected: Boolean = false,
  val isConnecting: Boolean = false,
  val error: String? = null,
)
